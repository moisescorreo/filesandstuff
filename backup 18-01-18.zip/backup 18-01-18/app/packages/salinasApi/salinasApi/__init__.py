import requests
import json
from collections import OrderedDict
from random import randint
import os
#from time import sleep 
import time

BASE_URL = os.environ['BASE_URL_API_SALINAS']
#Clase que ayuda a ordenar los JSONS
class JSONObject:
	def __init__(self, d):
		self.__dict__ = d

class SalinasApi():
	def printConfig(self):
		print(self.BASE_URL)

	def generarEnvio(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + '/message/'
		#Hace la peticion y la respuesta la guarda en la variable
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.put(generarUrl,json=requestParams,verify=False)
		#Si el servidor contesta exitosamente entra a la sentencia		
		if peticionEnviar.status_code == 200:
			#Parsea el json
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			#Obtiene el mensaje de salida del json y lo almacena
			operacion = datos.mensajeSalida
			#print(dic)
			#Regresa True y el mensaje de salida
			print("********************************************")
			print("Services generarEnvio: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return True,operacion

		elif peticionEnviar.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			pass
		pass

	def findForName(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + 'busquedas/porNombre'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.post(generarUrl,json=requestParams,verify=False)
	
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.mensajeSalida
			print("********************************************")
			print("Services findForName: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return True,operacion

		elif peticionEnviar.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass

	def findForBeneficiario(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + 'busquedas/porBeneficiario'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.post(generarUrl,json=requestParams,verify=False)
	
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.mensajeSalida
			#print(dic)
			print("********************************************")
			print("Services findForBeneficiario: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return True,operacion

		elif peticionEnviar.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass
	
	def ClientAltaRemitente(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + 'cliente/alta/remitente'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.put(generarUrl,json=requestParams,verify=False)
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.idCliente
			response = datos.mensajeSalida
			#print(dic)
			print("********************************************")
			print("Services ClientAltaRemitente: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return [True,response,operacion]


		elif peticionEnviar.status_code == 400:
			print(peticionEnviar.text)
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass
	
	def ClientAltaBeneficiario(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + 'cliente/alta/beneficiario'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.put(generarUrl,json=requestParams,verify=False)
		print(peticionEnviar.text)
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.idCliente
			response = datos.mensajeSalida
			#print(dic)
			operacion = int(operacion)
			print("********************************************")
			print("Services ClientAltaBeneficiario: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return [True,response,operacion]

		elif peticionEnviar.status_code == 400:
			return [False,"Error en el JSON"]
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass

	def ClientValida(requestParams):
		start = time.time()
		print("Cliente Valida")
		print(requestParams)
		generarUrl = BASE_URL + 'cliente/valida'
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.post(generarUrl,json=requestParams,verify=False)
		print(peticionEnviar.text)
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.bloqueOfac
			response = datos.mensajeSalida
			print("********************************************")
			print("Services ClientValida: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return [True,response,operacion]

		elif peticionEnviar.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass

	def EnvioCotiza(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + 'envio/cotiza'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.post(generarUrl,json=requestParams,verify=False)
		print("COTIZACION PREVIA")
		print(peticionEnviar.text)
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			response = datos.mensajeSalida
			operacion = datos.montoTotal
			#print(dic)
			print("********************************************")
			print("Services EnvioCotiza: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return [True,operacion,response]

		elif peticionEnviar.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass


	def soloCotiza(requestParams):
		start = time.time()
		print(requestParams)

		generarUrl = BASE_URL + 'envio/cotiza'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		print ("------------------------------------------------")
		print (requestParams)
		print ("------------------------------------------------")
		peticionEnviar = session.post(generarUrl,json=requestParams, verify=False)
		print("SOLO COTIZACION PREVIA")
		print(peticionEnviar.text)
		print("1")
		if peticionEnviar.status_code == 200:
			print("entro")
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			response = datos.mensajeSalida
			operacion = datos.montoTotal
			#print(dic)

			print("********************************************")
			print("Services soloCotiza: ")
			end = time.time()
			print(end - start)
			print("********************************************")
			return [True,operacion,response]

		elif peticionEnviar.status_code == 400:
			print("peticion con 400")
			return False,"Error en el JSON"
		
		else:
			print("peticion sin 200 codigo de error "+ str(peticionEnviar.status_code))
			print (peticionEnviar.json)
			return False,peticionEnviar.json['mensajeSalida'],{}
		pass

	def EnvioGenera(requestParams):
		print("ENVIO GENERA!!")
		start = time.time()
		generarUrl = BASE_URL + 'envio/generar'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		print(requestParams)
		peticionEnviar = session.put(generarUrl,json=requestParams, verify=False)
		print(peticionEnviar.text)
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			if datos.codigoSalida == "E":
				response = datos.mensajeSalida
				operacion=datos.folioTransferancia
				tarifa = datos.tarifa
				descuentoCF = datos.descuentoCF
				monto = datos.montoEnviadoMD
				saldoAbonadoMon = datos.saldoAbonadoMon
				tcfx = datos.tcfx
				descuentoCupon = datos.montoDescuentoCupon
				claveSeguridad = datos.claveSeguridad
				montoTotal = datos.montoTotal
				montoEnvioMG = datos.montoEnvioMG
				referenciaPreenvio = datos.referenciaPreenvio
				codigoSalida = datos.codigoSalida
				mensajeSalida = datos.mensajeSalida
				print("********************************************")
				print("Services EnvioGenera: ")
				end = time.time()
				print(end - start)
				print("********************************************")
				return [True,operacion,tarifa,descuentoCF,monto,saldoAbonadoMon,tcfx,descuentoCupon,claveSeguridad,montoTotal,montoEnvioMG,referenciaPreenvio,codigoSalida,mensajeSalida]
			else:
				return [True,datos.codigoSalida]

		elif peticionEnviar.status_code == 400:
			print(peticionEnviar.text)
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass


	def EnvioPld(requestParams):
		print("LO QUE ESTOY ENVIENDO EN PLD")
		print(requestParams)
		generarUrl = BASE_URL + 'cliente/alta/datosPld'
		session = requests.Session()
		session.trust_env = False
		peticionEnviar = session.put(generarUrl,json=requestParams, verify=False)
		print("LO QUE CONTESTO EL SERVICIO ES: ----")
		print(peticionEnviar.text)
		if peticionEnviar.status_code == 200:
			
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.codigoSalida

			return True,operacion

		else:
			return False


	def EnvioConfirma(requestParams):
		start = time.time()
		print(requestParams)
		generarUrl = BASE_URL + 'envio/confirma'
		# json = json.dumps(requestParams)
		session = requests.Session()
		session.trust_env = False
		#session.keep_alive = False
		peticionEnviar = session.put(generarUrl,json=requestParams, verify=False)
		
		if peticionEnviar.status_code == 200:
			dic = peticionEnviar.text
			json_str = json.dumps(dic)
			dic = json.loads(json_str)
			datos = json.loads(dic,object_pairs_hook=OrderedDict)
			datos = json.loads(dic,object_hook=JSONObject)
			operacion = datos.mensajeSalida
			#print(dic)
			print("********************************************")
			print("Services EnvioConfirma: ")
			end = time.time()
			print(end - start)
			print("********************************************")

			return True,operacion

		elif peticionEnviar.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			# return False,peticionEnviar.json['mensajeSalida'],{}
			pass
		pass


class peticiones():
	def generaEnvioP(self):
		jsonSend = {
	"uid":"UID000000000001",
	"paisId":1,
	"agenteId":133,
	"subsidiariaId":1,
	"sucursalId":1,
	"usuarioId":"PREENVIOFB",
	"numCteRemitenteId":130360123,
	"numCteBeneficiarioId":130360127,
	"monedaEnvioId":1,
	"montoEnvio":100.0,
	"paisDestinoId":1,
	"estadoDestinoId":1,
	"ciudadDestinoId":16,
	"monedaDestinoId":1,
	"mensajeCliente":"ENVIO PRUEBA TRU",
	"tipoEnvio":16
		}

		responsServer = SalinasApi.generarEnvio(self,jsonSend)
		return(responsServer)

	def busquedaPorNombreP(uid,nombre,apPaterno,apMaterno,fechaNacCte):
		jsonSend = {
	"uid":uid,
	"paisId":1,
	"agenteId":133,
	"subsidiariaId":1,
	"sucursalId":9559,
	"usuarioId":"PREENVIOFB",
	"nombreCte":nombre.upper(),
	"apPaternoCte":apPaterno.upper(),
	"apMaternoCte":apMaterno.upper(),
	"fechaNacCte":fechaNacCte,
	}

		responsServer = SalinasApi.findForName(jsonSend)
		return(responsServer)

	def busquedaBeneficiarioP(self):
		jsonSend =  {
	"uid":"UID000000000001",
	"paisId":1,
	"agenteId":133,
	"subsidiariaId":1,
	"sucursalId":1,
	"usuarioId":"PREENVIOFB",
	"clienteId":"130360123",
	}


		responsServer = SalinasApi.findForBeneficiario(self,jsonSend)
		return(responsServer)

	def ClientAltaRemitenteP(uid,nombre,apPaterno,apMaterno,fechaNacCte,colonia,estado=None,municpio = None,calle = None,cp = None): #calle
		jsonSend = {
	"uid":uid,
	"paisId":1,
	"agenteId":133,
	"subsidiariaId":1,
	"sucursalId":1,
	"usuarioId":"PREENVIOFB",
	"primerNombre":nombre.upper(),
	"apPaterno":apPaterno.upper(),
	"apMaterno":apMaterno.upper(),
	"fechaNacimiento":fechaNacCte,
	"paisIdentificacion":1,
	"tipoIdentificacionId":"1",
	"folioIdentificacion":"0",
	"nombrePais":"MEXICO",
	"nombreEstado":estado.upper(),
	"nombreColonia":colonia.upper(),
	"nombreMunicipio":municpio.upper(),
	"calleNumero": calle.upper(),
	"codigoPostal":cp,
	"clienteCertificado":0
	}
	#"calleNumero": calle.upper(),


		responsServer = SalinasApi.ClientAltaRemitente(jsonSend)
		return(responsServer)

	def ClientAltaBeneficiarioP(uid,nombre,apPaterno,apMaterno,idCliente):
		jsonSend = {
   "uid":uid,
   "paisId":1,
   "agenteId":133,
   "subsidiariaId":1,
   "sucursalId":1,
   "usuarioId":"PREENVIOFB",
   "primerNombre":nombre.upper(),
   "apPaterno":apPaterno.upper(),
   "apMaterno":apMaterno.upper(),
   "paisIdentificacion":1,
   "tipoIdentificacionId":1,
   "clienteRemitenteId":idCliente,
   "nombreEstado":"SONORA"
	}

		responsServer = SalinasApi.ClientAltaBeneficiario(jsonSend)
		return(responsServer)
	
	def ClientValidaP(uid,nombre,apPaterno,apMaterno,fechaNacimiento):
		jsonSend = {
    "uid":uid,
    "paisId":1,
    "agenteId":133,
    "subsidiariaId":1,
    "sucursalId":1,
    "usuarioId":"PREENVIOFB",
    "nombreCte":nombre.upper(),
    "apPaternoCte":apPaterno.upper(),
    "apMaternoCte":apMaterno.upper(),
    "fechaNacimientoCte":fechaNacimiento,
    "numeroEconomico":1,
    "negocioId":2,
    "caja":"FACEBOOK",
  	}

		responsServer = SalinasApi.ClientValida(jsonSend)
		return(responsServer)

	def EnvioCotizaP(uid,idCliente,monto):
		jsonSend = {
    "uid":uid,
    "paisId":1,
    "agenteId":133,
    "subsidiariaId":1,
    "sucursalId":1,
    "usuarioId":"PREENVIOFB",
    "numCteRemitenteId":idCliente,
    "monedaEnvioId":1,
    "montoEnvio":monto,
    "paisDestinoId":1,      
    "estadoDestinoId":1,
    "ciudadDestinoId":1,
    "monedaDestinoId":1,
    "tipoEnvio":16,
    "montosAcumulados":{}
	}


		responsServer = SalinasApi.EnvioCotiza(jsonSend)
		return(responsServer)

	def soloCotizaP(uid,monto):
		jsonSend = {
    "uid":uid,
    "paisId":1,
    "agenteId":133,
    "subsidiariaId":1,
    "sucursalId":1,
    "usuarioId":"PREENVIOFB",
    "numCteRemitenteId":0,
    "monedaEnvioId":1,
    "montoEnvio":int(monto),
    "paisDestinoId":1,      
    "estadoDestinoId":1,
    "ciudadDestinoId":1,
    "monedaDestinoId":1,
    "tipoEnvio":16,
    "montosAcumulados":{}
	}


		responsServer = SalinasApi.soloCotiza(jsonSend)
		return(responsServer)

	def EnvioGeneraP(uid,numCteRemitenteId,numCteBeneficiarioId,monto):


		jsonSend ={
		"uid":uid,
		"paisId":1,
		"agenteId":133,
		"subsidiariaId":1,
		"sucursalId":1,
		"usuarioId":"PREENVIOFB",
		"numCteRemitenteId":numCteRemitenteId,
		"numCteBeneficiarioId":numCteBeneficiarioId,
		"monedaEnvioId":1,
		"montoEnvio":monto,
		"paisDestinoId":1,
		"estadoDestinoId":1,
		"ciudadDestinoId":1,
		"monedaDestinoId":1,
		"mensajeCliente":"ENVIO BOT FACEBOOK",
		"agenteDestinoId":1,
		"subsidiariaDestinoId":1,
		"clasificacionAgenteId":1,
		"tipoEnvio":16,
		}


		responsServer = SalinasApi.EnvioGenera(jsonSend)
		return(responsServer)

	def EnvioPldP(uid,folioTransferencia,clienteId,calleNum,colonia,cp,estado,municipio,fechaNacimiento):
		print("Peticion")
		jsonSend = {
		"uid":uid,
		"paisId":1,
		"agenteId":133,
		"subsidiariaId":1,
		"sucursalId":1,
		"usuarioId":"PREENVIOFB",
		"folioTransferencia":str(folioTransferencia),
		"tipoOperacion":1,
		"clienteId":int(clienteId),
		"fechaNacimiento":fechaNacimiento,
		"datosExtra":[
				{
				"fiTipoDatoId":13,
				"fiDatoId":1,
				"fcValorDato":calleNum.upper(),
				"fiIdentificadorId":1
				},
				{
				"fiTipoDatoId":13,
				"fiDatoId":2,
				"fcValorDato":colonia.upper(),
				"fiIdentificadorId":2
				},
				{
				"fiTipoDatoId":13,
				"fiDatoId":21,
				"fcValorDato":str(cp),
				"fiIdentificadorId":19
				},
				{
				"fiTipoDatoId":13,
				"fiDatoId":4,
				"fcValorDato":estado.upper(),
				"fiIdentificadorId":4
				},
				{
				"fiTipoDatoId":13,
				"fiDatoId":3,
				"fcValorDato":municipio.upper(),
				"fiIdentificadorId":3
				}
				]
		}

		print("ARME")
		#print(prueba.EnvioPldP("UID955900001629",40188820063,146700756,"C AHUEHUETE SIN","Sta maria",54680,"04/10/96"))

		responsServer = SalinasApi.EnvioPld(jsonSend)
		print(responsServer)
		return responsServer



	def EnvioConfirmaP(uid,refTransferencia):
		jsonSend ={
		"uid":uid,
		"paisId":1,
		"agenteId":133,
		"subsidiariaId":1,
		"sucursalId":1,
		"usuarioId":"PREENVIOFB",
		"refTransferencia":refTransferencia,
		"paisIdentificacion":1,
		"tipoIdentificacion":1,
		"montoTotal":119,
	}

		responsServer = SalinasApi.EnvioConfirma(jsonSend)
		return(responsServer)

	def busquedaTiendaP(latitude,longitude):
		SERVICE_URL = os.environ['SERVICE_URL_LOCATION_STORES']
		url = SERVICE_URL + "GetNearByStores?latitude=%s&longitude=%s&radius=10&unitBusinessId=1" % (latitude, longitude)
		peticionBusquedaTienda = requests.get(url)
		sucursales = []
		if peticionBusquedaTienda.status_code == 200:
			response = peticionBusquedaTienda.json()
			numSucursales = len(response['Result'])
			if numSucursales < 5:
				for r in range(numSucursales):
					sucursales.append(response['Result'][r])
			else:
				for r in range(5):
					sucursales.append(response['Result'][r])
			return [True,sucursales]

		elif peticionBusquedaTienda.status_code == 400:
			return False,"Error en el JSON"
		
		else: 
			raise ValueError('Error en la petición')
			pass
		pass
