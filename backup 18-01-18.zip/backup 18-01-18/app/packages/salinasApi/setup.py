from setuptools import setup

setup(name='salinasApi',
      version='0.1',
      description='salinas api for bot',
      author='Mariachi IO',
      author_email='raul@mariachi.io',
      packages=['salinasApi'],
      zip_safe=False)