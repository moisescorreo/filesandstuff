#!/usr/bin/env python
# -*- coding: utf-8 -*-
from modules.send_image import send_image_url_references
import modules.ticket as ticket
import os
import random
import json
import requests
import time
import datetime

BASE_URL = os.environ['URL_IMG']

class RepliesBot(object):
    
	def __init__(self,bot):
		self.bot = bot
		self.elements = {'state10':[
					#{'title': 'Enviar dinero', 
						  #'image_url': os.environ['URL_IMG']+'/img/enviar-dinero.jpg', 
					#	  'image_url': "http://res.cloudinary.com/antikytheraton/image/upload/v1498686558/enviar-dinero_ufh2qm.jpg", 
					#	  'subtitle': 'Haz envíos de dinero a todo el país',
					#	  'buttons':[{'type': 'postback','title': 'Quiero enviar Dinero', 'payload': 50}]
					#	  },
						  {'title': 'Enviar dinero',
						  #'image_url': os.environ['URL_IMG']+'/img/cotizar.jpg',
						  'image_url': "https://www.qabot.dineroexpress.com.mx/img/envio-dinero.jpg",
						  'subtitle': 'Haz envíos de dinero a todo el país',
						  'buttons':[{'type': 'postback', 'title':'Quiero enviar Dinero', 'payload': 220}]
						  },
						  {'title': 'Localiza puntos de pago cercanos', 
						  #'image_url': os.environ['URL_IMG']+'/img/sucursales.jpg', 
						  'image_url': "https://www.qabot.dineroexpress.com.mx/img/puntos-de-pago.jpg",
						  'subtitle': 'Encuentra el punto de pago más próximo a ti',
						  'buttons':[{'type':'postback', 'title': 'Quiero buscar Puntos de pago', 'payload': 210}]
						  },
						  {'title': 'Ayuda', 
						  #'image_url': os.environ['URL_IMG']+'/img/ayuda.jpg', 
						  'image_url': "https://www.qabot.dineroexpress.com.mx/img/ayuda.jpg",
						  'subtitle': 'Sección de ayuda',
						  'buttons':[{'type': 'postback', 'title': 'Contactar a un humano', 'payload': 32}]}
						  ]}
		self.buttons = {'state7':[{"type":"phone_number","title":"Lada sin costo","payload": "018000517777" }],
			   'state10':[{"type":"postback","title":"Enviar dinero","payload": 50 },
						  {"type":"postback","title":"Localiza sucursales cercanas","payload": 210 },
						  {"type":"postback","title":"Ayuda","payload": 30 }],
			   'state30':[{"type":"postback","title":"Términos y condiciones","payload": 40 }],
			   'state210':[{"type":"phone_number","title":"Llamar","payload": "018000517777" },
						  {"type":"web_url","title":"Escribir correo","url":"http://mailto:info@elektra.com.mx"}],
			   'state70':[{"type":"postback","title":"Seleccionar beneficiario","payload": 80 },
						  {"type":"postback","title":"Nuevo beneficiario","payload": 60 }],
			   'state71':[{"type":"postback","title":"Seleccionar beneficiario","payload": 80 }]}
		self.replies = {'state90':[{"content_type":"text","title":"$300","payload":"300"},
						  {"content_type":"text","title":"$500","payload":"500"},
						  {"content_type":"text","title":"$1000","payload":"1000"},
						  {"content_type":"text","title":"Otra Cantidad","payload":"quick_replice"},],
				'state124':[{"content_type": "text", "title": "Si", "payload": "Si"},
						   {"content_type": "text", "title": "No", "payload": "No"},
						   {"content_type": "text", "title":"En otro momento", "payload": "Otro"}],
				'stateS/N':[{"content_type":"text","title":"Si","payload":"Si"},
						  {"content_type":"text","title":"No","payload":"No"}],
				'callCenterS/N':[{"content_type":"text","title":"Si","payload":"Si"},
						  {"content_type":"text","title":"No","payload":"No"}],
				'CancelarCallCenterS/N':[{"content_type":"text","title":"Si","payload":"CancelarCallCenterS"},
						  {"content_type":"text","title":"No","payload":"CancelarCallCenterN"}],
				'stateS/N/T':[{"content_type":"text","title":"Si","payload":"Si"},
						  {"content_type":"text","title":"No","payload":"No"},
						  {"content_type":"text","title":"Consultar Términos y Condiciones","payload":"TYC"}],
				'state_MP':[{"content_type":"text","title":"Menú principal","payload":"MENU" }],
				'state150':[{"content_type":"text","title":"Si","payload":"Si"},
						  {"content_type":"text","title":"No","payload":"No"},
						  {"content_type":"text","title":"Cambiar beneficiario","payload":"70"},
						  {"content_type":"text","title":"Cambiar monto","payload":"90"}],
				'state190':[{"content_type":"location", "title":"Si quiero"},
							{"content_type":"text","title":"En otro momento","payload":"No_location"}],
				'state85':[{"content_type":"text","title":"A - C","payload":"1"},
						  {"content_type":"text","title":"D - M","payload":"2"},
						  {"content_type":"text","title":"N - S","payload":"3"},
						  {"content_type":"text","title":"T - Z","payload":"4"}],
				'state61':[{"content_type":"text","title":"Si quiero","payload":"1"},
						   {"content_type":"text","title":"En otro momento","payload":"1"},],
				'state_area_1':[{"content_type":"text","title":"Aguascalientes","payload":"Aguascalientes"},
						  {"content_type":"text","title":"Baja California","payload":"Baja California"},
						  {"content_type":"text","title":"Baja California Sur","payload":"Baja California Sur"},
						  {"content_type":"text","title":"Campeche","payload":"Campeche"},
						  {"content_type":"text","title":"Chiapas","payload":"Chiapas"},
						  {"content_type":"text","title":"Chihuahua","payload":"Chihuahua"},
						  {"content_type":"text","title":"Ciudad de México","payload":"CIUDAD DE MÉXICO"},
						  {"content_type":"text","title":"Coahuila","payload":"Coahuila"},
						  {"content_type":"text","title":"Colima","payload":"Colima"},
						  {"content_type":"text","title":"Volver","payload":"back"}],
				'state_area_2':[{"content_type":"text","title":"Ciudad de México","payload":"CIUDAD DE MÉXICO"},
						  {"content_type":"text","title":"Durango","payload":"Durango"},
						  {"content_type":"text","title":"Estado de México","payload":"México"},
						  {"content_type":"text","title":"Guanajuato","payload":"Guanajuato"},
						  {"content_type":"text","title":"Guerrero","payload":"Guerrero"},
						  {"content_type":"text","title":"Hidalgo","payload":"Hidalgo"},
						  {"content_type":"text","title":"Jalisco","payload":"Jalisco"},
						  {"content_type":"text","title":"Michoacán","payload":"Michoacan"},
						  {"content_type":"text","title":"Morelos","payload":"Morelos"},
						  {"content_type":"text","title":"Volver","payload":"back"}],
				'state_area_3':[{"content_type":"text","title":"Nayarit","payload":"Nayarit"},
						  {"content_type":"text","title":"Nuevo León","payload":"Nuevo Leon"},
						  {"content_type":"text","title":"Oaxaca","payload":"Oaxaca"},
						  {"content_type":"text","title":"Puebla","payload":"Puebla"},
						  {"content_type":"text","title":"Querétaro","payload":"Queretaro"},
						  {"content_type":"text","title":"Quintana Roo","payload":"Quintana Roo"},
						  {"content_type":"text","title":"San Luis Potosí","payload":"San Luis Potosi"},
						  {"content_type":"text","title":"Sinaloa","payload":"Sinaloa"},
						  {"content_type":"text","title":"Sonora","payload":"Sonora"},
						  {"content_type":"text","title":"Volver","payload":"back"}],
				'state_area_4':[{"content_type":"text","title":"Tabasco","payload":"Tabasco"},
						  {"content_type":"text","title":"Tamaulipas","payload":"Tamaulipas"},
						  {"content_type":"text","title":"Tlaxcala","payload":"Tlaxcala"},
						  {"content_type":"text","title":"Veracruz","payload":"Veracruz"},
						  {"content_type":"text","title":"Yucatán","payload":"Yucatan"},
						  {"content_type":"text","title":"Zacatecas","payload":"Zacatecas"},
						  {"content_type":"text","title":"Volver","payload":"back"}],
				'state153':[{'content_type':'text','title':'Comisión Alta','payload':'Comisión Alta'},
						  {'content_type':'text','title':'No entendí el proceso','payload':'No entendí el proceso'},
						  {'content_type':'text','title':'Solo fue una prueba','payload':'Solo fue una prueba'},
						  {'content_type':'text','title':'Otro Motivo','payload':'OTRO'}],
				'state33':[{'content_type':'text','title':'No entendí el proceso','payload':'No entendí el proceso'},
						  {'content_type':'text','title':'Solo fue una prueba','payload':'Solo fue una prueba'}],
				'state230':[{'content_type':'text','title':'Tarjeta Cred/Deb','payload':'TCD'},
                          {'content_type':'text','title':'Pago en sucursal','payload':'PUNTO'}]
						  }

	def state_location(self,sender_id,coordinates):
		message = "Enviaste localización"
		self.bot.send_text_message(sender_id, message)

	def send_alert(self,sender_id, message):
		'''Alert'''
		self.bot.send_text_message(sender_id, message)

	#Metodo que simula el typing y el visto
	def send_action (self,sender_id,action):
		if action==1:
			self.bot.send_action(sender_id,'typing_on')
		elif action==2:
			self.bot.send_action(sender_id,'typing_off')
		else:
			self.bot.send_action(sender_id,'mark_seen')


	def validate_day_hour(self):
		now=datetime.datetime.now()
		#day_of_week=datetime.datetime.today().weekday()
		hour_start=9
		hour_end=20

		#if day_of_week<7 and now.hour>=hour_start and now.hour<= hour_end:
		if now.hour>=hour_start and now.hour<= hour_end:
			return True
		else:
			return False


	def state_verify_states(self,sender_id,state):
		text = "¿El estado es " + state+"?"

		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])


	def state_verify(self,sender_id, names):
		'''Verify names'''
		text = "Por favor confírmanos que el nombre sea correcto:\nNombre(s): "+names[0].upper()+"\nApellido paterno: "+names[1].upper()+"\nApellido materno: "+names[2].upper()
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])

	def state_verify_address(self,sender_id, street):
		'''Verify street'''
		text = "Finalmente, confírmanos que tu dirección esté completa y correcta:\nCalle: "+street['calle_num'].upper()+"\nColonia: "+street['colonia'].upper()+"\nCódigo Postal: "+street['codigo_postal'].upper()
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])


	def show_yes_no(self,sender_id, text):
		'''Verify names'''
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])


	def state_verify_date(self,sender_id,name,date):
		text = "¿Tu fecha de nacimiento es\n" +date+"?"
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])

	def state_restart(self, sender_id, name):
		'''Reinicio del bot'''
		text = "¿Te puedo ayudar con algo más "+name+"? ;)"
		self.bot.send_text_message(sender_id, text)
		self.bot.send_generic_message(sender_id, self.elements['state10'])


	def state_4(self, sender_id):
		text = "Lo siento, no entendí tu respuesta. Volvamos a intentar ;)"
		self.bot.send_text_message(sender_id, text)


	def state_menu(self, sender_id, text):
		'''Respuesta rápida para enviar dinero'''
		self.bot.send_quick_replies(sender_id, text, self.replies['state_MP'])


	def state_exit(self, sender_id, name):
		'''Despedida del bot'''
		message = "Si tienes alguna duda y/o sugerencia nos puedes contactar al 01800-0517-777"
		self.bot.send_quick_replies(sender_id, message,self.replies['state_MP'])

	def state_5(self, sender_id):
		'''Cancelar operación'''
		message = "Operación cancelada"
		self.bot.send_text_message(sender_id, message)

	def state_6(self, sender_id):
		'''Tutorial'''
		message = "Tutorial"
		self.bot.send_text_message(sender_id, message)


	def state_7(self, sender_id,):
		'''Contacto'''
		text = "Centro de atención a clientes"
		self.bot.send_button_message(sender_id, text, self.buttons['state7'])


	def state_10(self,sender_id, name):
		'''Presentación bot'''
		message = "¡Hola "+name.upper()+"! soy el robot de 🤖 Dinero Express, aquí te ayudaremos a enviar dinero fácil y rápido. :D" 
		self.bot.send_text_message(sender_id, message)
		text = "¿Qué deseas hacer hoy?"
		self.bot.send_generic_message(sender_id, self.elements['state10'])


	def state_30(self,sender_id):
		'''Opciones de ayuda'''
		text = "¿Cómo puedo ayudarte?"
		self.bot.send_button_message(sender_id, text, self.buttons['state30'])


	def state_40(self,sender_id):
		'''Términos y condiciones, Políticas de privacidad'''
		elements = [
           {
            "title":"Términos y condiciones",
            "image_url":"https://www.qabot.dineroexpress.com.mx/img/imagen2.jpeg",
            "buttons":[
              {
                "type":"web_url",
                "url":"https://www.qabot.dineroexpress.com.mx/condiciones",
                "title":"Ver términos y condiciones"
              }             
            ]      
          },
          {
            "title":"Políticas de privacidad",
            "image_url":"https://www.qabot.dineroexpress.com.mx/img/imagen2.jpeg",
            "buttons":[
              {
                "type":"web_url",
                "url":"https://www.qabot.dineroexpress.com.mx/avisos",
                "title":"Ver políticas"
              }             
            ]      
          }
        ]
		self.bot.send_generic_message(sender_id, elements)


	def state_60(self,sender_id, name):
		'''Datos del beneficiario'''
		message="Comencemos… ¿Cuál es el nombre de la persona que recibirá el dinero? Te sugerimos incluir nombres y apellidos."
		self.bot.send_text_message(sender_id,message)


	def state_63(self, sender_id):
		message = "¿Cuál es el primer y segundo nombre de quien recibirá el dinero?"
		self.bot.send_text_message(sender_id, message)


	def state_64(self, sender_id):
		message = "Gracias ¿Me podrías decir cuál es su apellido paterno?"
		self.bot.send_text_message(sender_id, message)

	def state_65(self, sender_id):
		message = "¿Me ayudas con el apellido materno?"
		self.bot.send_text_message(sender_id, message)

	def state_70(self,sender_id):
		text = "¿Quién recibirá el dinero?"
		self.bot.send_button_message(sender_id, text, self.buttons['state70'])


	def state_71(self,sender_id):
		text = "Haz alcanzado el número máximo de beneficiarios registrados"
		self.bot.send_text_message(sender_id,text)
		text = "Para agregar uno nuevo debes borrar algunos de tus contactos"
		self.bot.send_text_message(sender_id,text)
		text = "¿Quién recibirá el dinero?"
		self.bot.send_button_message(sender_id,text,self.buttons['state71'])


	def state_80(self,sender_id, contacts):
		'''Seleccionar beneficiarios frecuentes'''
		#Example constacts
		message = "Selecciona una opción de tu lista de beneficiarios."
		self.bot.send_text_message(sender_id, message)
		contactos = ["https://www.qabot.dineroexpress.com.mx/img/contacto1.jpg",
					 "https://www.qabot.dineroexpress.com.mx/img/contacto2.jpg",
					 "https://www.qabot.dineroexpress.com.mx/img/contacto3.jpg"]
		elements = []
		for contact in range(len(contacts)):
			buttons = [{"type":"postback","title":"Seleccionar","payload": "S"+str(contacts[contact]['idBeneficiario'])},
					   {"type":"postback","title":"Borrar","payload": "B"+str(contacts[contact]['idBeneficiario'])},]

			element = {"title":contacts[contact]['nombre']+" "+contacts[contact]['apPaterno']+" "+contacts[contact]['apMaterno'],
					  	"image_url":random.choice(contactos),
					  	"buttons":buttons}
			elements.append(element)
		self.bot.send_generic_message(sender_id, elements)


	def state_82(self,sender_id,name,apPaterno,apMaterno):
		text= "En que estado ahora cobrará el dinero "+name.upper()+" "+apPaterno.upper()+" "+apMaterno.upper()+"?"

		self.bot.send_text_message(sender_id,text)

	
	def state_85(self,sender_id):
		text= "Elige el estado deseado de alguna de las siguientes listas ordenadas alfabéticamente:"
		self.bot.send_quick_replies(sender_id,text,self.replies['state85'])

	def state_91(self,sender_id,name,apPaterno,apMaterno):
		message = "Ahora dinos, ¿En qué Estado de la República cobrará el dinero "+name.upper()+" "+apPaterno.upper()+" "+apMaterno.upper()+"?"
		self.bot.send_text_message(sender_id,message)


	def state_90(self,sender_id, recipient_name):
		'''Monto'''
		text = "¿Cuánto dinero quieres enviarle a "+recipient_name.upper()+"?"
		self.bot.send_quick_replies(sender_id,text,self.replies['state90'])


	def state_110(self,sender_id, name):
		'''Datos del usuario'''
		message = "¡Gracias "+name.upper()+"!…\n Para continuar con tu envío y por única ocasión necesitaremos algunos de tus datos."
		self.bot.send_text_message(sender_id, message)
		message = "Ayúdanos con tu nombre completo incluyendo tus apellidos."
		self.bot.send_text_message(sender_id, message)


	def state_113(self, sender_id):
		message = "¿Cuál es tu primer y segundo nombre?"
		self.bot.send_text_message(sender_id, message)

	def state_114(self, sender_id):
		message = "Gracias ¿Me podrías decir cuál es tu apellido paterno?"
		self.bot.send_text_message(sender_id, message)


	def state_115(self, sender_id):
		message = "¿Me ayudas con tu apellido materno?"
		self.bot.send_text_message(sender_id, message)


	def state_120(self,sender_id, name):
		'''Corregir fecha de nacimiento'''
		message = name.upper()+" ¿Puedes decirnos tu fecha de nacimiento? Te sugerimos usar un formato como este: \n 1/Enero/1992."
		self.bot.send_text_message(sender_id, message)

	def state_124(self,sender_id, name):
		'''Telefono celular del usuario'''
		text = "¿Deseas proporcionarnos tu número celular para recibir promociones?"
		self.bot.send_quick_replies(sender_id, text, self.replies['state124'])

	def state_126(self,sender_id, name):
		'''Pide telefono de usuario'''
		message = "Ingresa los 10 dígitos de tu número celular"
		self.bot.send_text_message(sender_id, message)

	def state_128(self,sender_id, name):
		'''Pide telefono de usuario, longitud incorrecta'''
		message = "El número de celular debe contener 10 dígitos, favor de verificar e ingresarlo de nuevo"
		self.bot.send_text_message(sender_id, message)

	def state_251(self,sender_id, name):
		'''Pide telefono de usuario, numero invalido'''
		message = "El número de celular no existe, favor de verificar e ingresarlo de nuevo"
		self.bot.send_text_message(sender_id, message)

	def state_130(self,sender_id, name):
		'''Domicilio usuario'''
		message = "Estamos a punto de terminar, sólo compártenos la calle, el número interior y/o exterior de tu domicilio"
		self.bot.send_text_message(sender_id, message)


	def state_133(self, sender_id):
		message = "¿Cuál es la calle y número de tu dirección?"
		self.bot.send_text_message(sender_id, message)


	def state_134(self, sender_id,name):
		message = "¿En qué colonia se ubica tu domicilio?"
		self.bot.send_text_message(sender_id, message)


	def state_135(self, sender_id):
		message = "Ahora tu Código Postal, por favor…"
		self.bot.send_text_message(sender_id, message)


	def state_137(self,sender_id):
		message = "Lo siento, no encontre tu código postal, ingresalo de nuevo."
		self.bot.send_text_message(sender_id,message)


	def state_139(self,sender_id,name):
		message = "Gracias"+name+". Por último una por la parte posterior de la identificación"
		self.bot.send_text_messages(sender_id,message)


	def state_150(self,sender_id, name, recipient_name,apPaterno,apMaterno, quantity, quantityF):
		'''Confirmar datos beneficiario, monto, usuario'''
		quantityF=int(quantityF)
		quantityMasExtra = (int(quantityF)+7) 
		comision = int(quantityF) - int(quantity)
		# Continuemos `Usuario`, elegiste enviar el `monto` a `beneficiario` para ser cobrados en `estado`
		message = name.upper()+"... Elegiste enviar $"+str(quantity)+" a "+recipient_name.upper()+" "+apPaterno.upper()+" "+apMaterno.upper()

		self.bot.send_text_message(sender_id, message)
		#text = "Para completar tu envío deberás acudir a un punto de pago donde te cobrarán $"+str(quantityMasExtra)+"\n\t - "+recipient_name.upper()+" recibirá $"+str(quantity)+"\n\t - Comisión de envío $"+str(comision)+"\n\t - Cargo extra del punto de pago $7 \n * Las comisiones incluyen IVA"
		#self.bot.send_text_message(sender_id, text)
		text = "¿Estás de acuerdo?"
		self.bot.send_quick_replies(sender_id,text,self.replies['state150'])

	def state_150_error(self, sender_id):
		text = "Responde con una de las siguientes opciones"
		self.bot.send_quick_replies(sender_id,text,self.replies['state150'])


	def state_160(self,sender_id):
		'''Lista negra'''
		message = "Lo siento, no puedo procesar su envío, por favor acuda a una sucursal"
		self.bot.send_text_message(sender_id, message)


	def state_161(self,sender_id):
		text = "Deseas saber los puntos mas cercanos a tu ubicación"
		self.bot.send_quick_replies(sender_id,text,self.replies['state161'])


	def state_170(self,sender_id, name, image_url,quantityF,folio):
		'''Notificación activación de código'''
		quantityF = int(quantityF)
		message = "Sigue estos pasos para realizar tu pago:"

		self.bot.send_text_message(sender_id, message)
		'''Generar ticket'''


		image = False
		while image == False:
			self.bot.send_action(sender_id,'typing_on')
			print("INTENTO!!")
			time.sleep(2)
			print("PASO 1 SEGUNDO")
			image = send_image_url_references(sender_id,image_url)
		print("PASE EL WHILE")

		self.bot.send_action(sender_id,'typing_off')
		'''Econtrar sucursales cercanas'''
		text = "Compártenos tu ubicación y te enviaremos el punto de servicio más cercano. 🏪\n¡Tenemos más de 5 mil en todo México! "
		self.bot.send_quick_replies(sender_id,text,self.replies['state190'])
		
	def state_180(self,sender_id, places,name):
		'''Mapa sucursales cercanas'''
		elements = []

		for place in range(len(places)):

			if places[place]['Channel'] == 'ELEKTRA':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/elektra.png"
			elif places[place]['Channel'] == 'NETO':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/neto.png"
			elif places[place]['Channel'] == 'FARMAPRONTO':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/farmapronto.jpg"
			elif places[place]['Channel'] == 'MTCENTER':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/mtcenter.jpg"
			elif places[place]['Channel'] == 'PAGAQUI':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/pagaqui.jpg"
			else:
				image_url = "https://www.qabot.dineroexpress.com.mx/img/gestopago.jpg"

			element = {"title":places[place]['NameSuc'].title(),
						"subtitle":places[place]['direccion'],
						"item_url":"https://www.google.com.mx/maps/place/"+str(places[place]['Latitude'])+","+str(places[place]['Longitude']),
					  	"image_url":image_url}
			elements.append(element)
		self.bot.send_generic_message(sender_id, elements)		


	def state_210(self,sender_id):
		'''Mapa sucursales cercanas'''
		message = ["Actívalo en la sucursal Elecktra o Banco Azteca más cerca de ti",
			   	   "También puedes activarlo con alguno de nuestros socios.\nFarmacias del ahorro, Tiendas Neto, Presta Prenda",
			   	   "¿Tienes alguna duda?"]
		self.bot.send_text_message(sender_id, message[0])
		self.bot.send_text_message(sender_id, message[1])
		self.bot.send_text_message(sender_id, message[2])
		text = "LLámanos o escríbenos un correo electrónico"


	def state_231(self,sender_id, name, name1):
		'''Notificación 1'''
		message = "Hola "+name.upper()+", te informo que "+name1.upper()+" acaba de cobrar el envío"
		self.bot.send_text_message(sender_id, message)


	def state_232(self,sender_id, name):
		'''Notificación 2'''
		message = "Hola "+name.upper()+", te informo que tu envío fue cancelado"
		self.bot.send_text_message(sender_id, message)


	def state_233(self,sender_id, name):
		'''Notificación 3'''
		message = "Hola "+name.upper()+", te informo que tu código de envío expiró"
		self.bot.send_text_message(sender_id, message)


	def state_area_1(self,sender_id):
		text = "A - C: "
		self.bot.send_quick_replies(sender_id,text,self.replies['state_area_1'])

	def state_area_2(self,sender_id):
		text = "D - M: "
		self.bot.send_quick_replies(sender_id,text,self.replies['state_area_2'])

	def state_area_3(self,sender_id):
		text = "N - S "
		self.bot.send_quick_replies(sender_id,text,self.replies['state_area_3'])

	def state_area_4(self,sender_id):
		text = "T - Z "
		self.bot.send_quick_replies(sender_id,text,self.replies['state_area_4'])

	def find_elektra_location(self,sender_id):
		text = "Envíanos tu ubicación para mostrarte los puntos de pago cercanos"
		self.bot.send_quick_replies(sender_id,text,self.replies['state190'])


	def show_stores(self,sender_id,places):
		elements = []
		for place in range(len(places)):
	
			if places[place]['Channel'] == 'ELEKTRA':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/elektra.png"
			elif places[place]['Channel'] == 'NETO':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/neto.png"
			elif places[place]['Channel'] == 'FARMAPRONTO':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/farmapronto.jpg"
			elif places[place]['Channel'] == 'MTCENTER':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/mtcenter.jpg"
			elif places[place]['Channel'] == 'PAGAQUI':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/pagaqui.jpg"
			else:
				image_url = "https://www.qabot.dineroexpress.com.mx/img/gestopago.jpg"

			element = {"title":places[place]['NameSuc'].title(),
						"subtitle":places[place]['direccion'],
						"item_url":"https://www.google.com.mx/maps/place/"+str(places[place]['Latitude'])+","+str(places[place]['Longitude']),
					  	"image_url":image_url}
			elements.append(element)
		self.bot.send_generic_message(sender_id, elements)


	def show_stores_menu(self,sender_id,places):
		elements = []
		for place in range(len(places)):
			if places[place]['Channel'] == 'ELEKTRA':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/elektra.png"
			elif places[place]['Channel'] == 'NETO':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/neto.png"
			elif places[place]['Channel'] == 'FARMAPRONTO':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/farmapronto.jpg"
			elif places[place]['Channel'] == 'MTCENTER':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/mtcenter.jpg"
			elif places[place]['Channel'] == 'PAGAQUI':
				image_url = "https://www.qabot.dineroexpress.com.mx/img/pagaqui.jpg"
			else:
				image_url = "https://www.qabot.dineroexpress.com.mx/img/gestopago.jpg"
			
			element = {"title":places[place]['NameSuc'].title(),
						"subtitle":places[place]['direccion'],
						"item_url":"https://www.google.com.mx/maps/place/"+str(places[place]['Latitude'])+","+str(places[place]['Longitude']),
					  	"image_url":image_url}
			elements.append(element)
		self.bot.send_generic_message(sender_id, elements)



	def state_cantidad(self,sender_id):
		message = "Introduce la cantidad a enviar, puede ser desde $20 hasta $1,000 pesos"
		self.bot.send_text_message(sender_id,message)

	def update_state(self,sender_id,nombre,image_url,total,f_tranferencia):
		total = int(total)
		text = "¡Buenas noticias! A partir de este momento "+str(nombre)+" ya puede recibir su dinero con la siguiente clave: "+str(f_tranferencia) 
		message = "Éste es tu comprobante de envío, te sugerimos compartirlo con "+str(nombre)
		self.bot.send_text_message(sender_id,text)
		self.bot.send_text_message(sender_id,message)
		image = False
		while image == False:
			self.bot.send_action(sender_id,'typing_on')
			print("INTENTO!!")
			time.sleep(2)
			print("PASO 1 SEGUNDO")
			image = send_image_url_references(sender_id,image_url)
		print("PASE EL WHILE")
		message = "Gracias por usar el servicio de Dinero Express, aquí estaremos para lo que necesites. ¡Hasta la próxima!"
		self.bot.send_text_message(sender_id,message)

	def state_153(self, sender_id, text):
		self.bot.send_quick_replies(sender_id, text, self.replies['state153'])

	def state_154(self, sender_id):
		message = "Escriba su motivo de cancelación"
		self.bot.send_text_message(sender_id, message)

	def state220(self, sender_id):
		message= "¿Cuánto dinero quieres enviar? Puede ser desde $20 hasta $1,000 pesos."
		self.bot.send_text_message(sender_id, message)

	"""def state225(self,sender_id,quantity,quantityF):
		quantityF=int(quantityF)
		quantityMasExtra = (int(quantityF)+7)
		comision = int(quantityF) - int(quantity)

		#text = "El monto que deberás pagar para completar el envío es de $" +str(quantityF)+" (incluye el monto a enviar más la comisión de Dinero Express y el IVA)."
		#self.bot.send_text_message(sender_id,text)
		
		text = "Para completar tu envío deberás acudir a un punto de servicio donde te cobrarán $"+str(quantityMasExtra)+"\n\t - TU BENEFICIARIO recibirá $"+str(quantity)+"\n\t - Comisión de envío $"+str(comision)+"\n\t - Cargo extra del punto de pago $7 \n * Las comisiones incluyen IVA"
		self.bot.send_text_message(sender_id,text)
		text = "¿Deseas continuar con el envío?"
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])"""

	def state_181(self,sender_id,name):
		#text = "Al continuar con el pago de tu referencia estás aceptando los términos y condiciones de Dinero Express."
		#self.bot.send_text_message(sender_id, text)
		text = name.upper()+" ⚠ tu envío aún no está completo. Te invitamos a realizar el pago de tu referencia"
		self.bot.send_text_message(sender_id, text)

	def update_state_cancel(self,sender_id,nombre,total,f_tranferencia):
		total = int(total)
		text = "Tu envío de $"+str(total)+" para " + str(nombre) + " con el folio de transferencia " + str(f_tranferencia) + " ha sido cancelado :("
		self.bot.send_text_message(sender_id,text)  

	def update_state_cobrado(self,sender_id,nombre,total,f_tranferencia):
		total = int(total)
		text = "Tu envío de $"+str(total)+" para " + str(nombre) + " con el folio de transferencia " + str(f_tranferencia) + " ha sido cobrado exitosamente :D"
		self.bot.send_text_message(sender_id,text)

	def state_68(self,sender_id):
		text = "¿Aceptas Términos y condiciones y el Aviso de Privacidad?\nEs necesario para continuar con tu envío."
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N/T'])

	def state_32(self, sender_id):
		text = "¿Deseas contactar a un humano?"
		self.bot.send_quick_replies(sender_id,text,self.replies['callCenterS/N'])
        
	def state_33(self, sender_id):
		text = "¿Cuáles son los motivos por los que deseas hablar con un humano?"
		self.bot.send_quick_replies(sender_id,text,self.replies['state33'])

	def state_230(self, sender_id):
		text = "¿Como deseas pagar tu envío?"
		self.bot.send_quick_replies(sender_id,text,self.replies['state230'])
        
	def state_230_error(self, sender_id):
		text = "Por favor responde con una de las siguientes opciones"
		self.bot.send_quick_replies(sender_id,text,self.replies['state230'])
    

	def state_234(self, sender_id):
		text = "Sigue estos pasos para realizar tu pago:"
		self.bot.send_text_message(sender_id,text)
		time.sleep(1)
		text = "Presiona el enlace a continuación y continua con el pago de tu envío con tarjeta de crédito o débito 💲💳"
		self.bot.send_text_message(sender_id,text)
		time.sleep(1)
		elements = [
           {
            "title":"Pago con tarjeta de crédito o débito",
            "image_url":"https://www.qabot.dineroexpress.com.mx/img/imagen2.jpeg",
            "buttons":[
              {
                "type":"web_url",
                "url":"https://www.qabot.dineroexpress.com.mx/avisos",
                "title":"Pagar",
                "webview_height_ratio": "tall",
                "messenger_extensions": True,
                "fallback_url":"https://www.qabot.dineroexpress.com.mx/avisos",
                "webview_share_button": "hide"
              }             
            ]      
          }
        ]
		print(elements)
		self.bot.send_generic_message(sender_id, elements)


	def state225(self,sender_id,quantity,quantityF,tipo):
		quantityF=int(quantityF)
		quantityMasExtra = (int(quantityF)+7) 
		quantityMasExtraTarjeta = (int(quantityF)+10) 
		comision = int(quantityF) - int(quantity)
		comisionTarjeta = (int(quantityF) - int(quantity)+10)
		if (tipo == 1):
			text = "Para completar tu envío deberas elegir entre acudir a un punto de pago donde te cobraran $ {}\n\t - TU BENEFICIARIO recibira ${}\n\t - Comision de envío ${}\n\t - Cargo extra del punto de pago $7 \n\n".format(str(quantityMasExtra),str(quantity),str(comision))
			self.bot.send_text_message(sender_id,text)
		else:
			text1 ="Puedes elegir pagar con cargo a tu tarjeta de crédito o débito 💳, el monto total que debes pagar por este envío son $ {}\n\t - TU BENEFICIARIO recibira ${}\n\t - Comisión por envío y uso de tarjeta ${}\n*Las comisiones incluyen IVA".format(str(quantityMasExtraTarjeta),str(quantity),str(comisionTarjeta))
			self.bot.send_text_message(sender_id,text1)

		text = "¿Deseas continuar con el envío?"
		self.bot.send_quick_replies(sender_id,text,self.replies['stateS/N'])
