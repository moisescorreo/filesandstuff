#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
from replies_bot import RepliesBot
import requests
import datetime
import json
from S1 import s1Module
from pymessenger.bot import Bot


s1Request = s1Module()


ACCESS_TOKEN = os.environ['ACCESS_TOKEN_FACEBOOK']
bot = Bot(ACCESS_TOKEN)


class storageConversationModule():

    def __init__(self, user, ora):
        self.user = user
        self.ora = ora

    def setMessage(self,sender_id,message):
        mensaje = message.replace('"',"'")
        mensaje = mensaje.replace('\u2018',"'")
        mensaje = mensaje.replace('\u201c',"'")
        mensaje = mensaje.replace('\u2019',"'")
        mensaje = mensaje.replace('\u20ac',"EURO")
        mensaje = mensaje.replace('\u2022',".")
        mensaje = mensaje.replace('&',"AND")
        mensaje = mensaje.encode('ascii', 'ignore')
        print("--------------Parametros Agregados a base de datos----------------------")
        print(str(mensaje.decode('unicode-escape')))
        self.ora.addMensaje(sender_id,str(mensaje.decode('unicode-escape')))
        print("------------------------------------------------------------------------")

    def setMessageStates(self,sender_id,message):
        states = {
                4: {"eventName":"(Bot) Detecta intentos fallidos y muestra texto de volver a intentar"},
                5: {"eventName":"mostrar_cancelar_transaccion"},
                6: {"eventName":"mostrar_numero_contacto"},
                7: {"eventName":"mostrar_yes_no"},
                10: {"eventName":"(BOT) El usuario saludo al bot"},
                20: {"eventName":"(BOT) El usuario presiono un boton del carousell de inicio"},
                30: {"eventName":"(Bot) El usuario presiono solicitar ayuda"},
                31: {"eventName":"Lee la acción del menú ayuda que eligió el usuario."},
                32: {"eventName":"mostrar.hablar_con_humano"},
                33: {"eventName":"leer.hablar_con_humano"},
                34: {"eventName":"leer.motivos_callcenter"},
                40: {"eventName":"mostrar_terminos_condiciones"},
                41: {"eventName":"(Bot) Muestra boton para regresar al menu principal"},
                42: {"eventName":"terminos_condiciones2"},
                50: {"eventName":"mostrar_verificar"},
                60: {"eventName":"mostrar_ingresa_nombre_beneficiario"},
                61: {"eventName":"(Bot) Lee el nombre completo del beneficiario y lo divide en nombre, apellidos paterno y materno"},
                62: {"eventName":"leer_confirmar_nombre_beneficiario"},
                63: {"eventName":"mostrar_corrige_nombre"},
                64: {"eventName":"(Bot) Lee el nombre del beneficiario de forma separada"},
                65: {"eventName":"(Bot) Lee el apellido del beneficiario de forma separada."},
                66: {"eventName":"(Bot) Lee el apellido materno del beneficiario de forma separada"},
                68: {"eventName":"(Bot) El usuario acepto los terminos y condiciones"},
                69: {"eventName":"leer_aceptar_terminos_condiciones"},
                70: {"eventName":"(Bot) Se mostraron los beneficiarios de fondeo"},
                71: {"eventName":"(Bot) El usuario ingreso el nombre del beneficiario"},
                80: {"eventName":"(Bot) se mostro la lista de beneficiarios"},
                81: {"eventName":"(Bot) El usuario selecciono el beneficiario de sus contactos"},
                82: {"eventName":"mostrar_pregunta_estado_editar"},
                85: {"eventName":"mostrar_despliega_estados"},
                86: {"eventName":"leer_selecciona_region"},
                87: {"eventName":"leer_selecciona_estado"},
                88: {"eventName":"leer_confirmar_estado"},
                89: {"eventName":"leer_region_federativa"},
                90: {"eventName":"(Bot) Muestra texto solicitando el monto a enviar,"},
                91: {"eventName":"mostrar_pregunta_estado"},
                100: {"eventName":"(Bot) El usuario ingreso la cantidad a enviar"},
                110: {"eventName":"(Bot) El bot muestra nombre del remitente"},
                111: {"eventName":"(Bot) El bot lee el nombre completo del remitente"},
                112: {"eventName":"(Bot) El bot muetra mensaje de confirmacion del remitente"},
                113: {"eventName":"(Bot) El bot muestra opcion de corregir el remitente"},
                114: {"eventName":"(Bot) El bot lee el nombre del remitente"},
                115: {"eventName":"(Bot) El bot lee el apellido del remitente"},
                116: {"eventName":"(Bot) El bot lee el apellido materno del remitente"},
                120: {"eventName":"(Bot) El bot muetra la fecha de nacimiento"},
                121: {"eventName":"(Bot) El bot lee la fecha  de nacimiento"},
                122: {"eventName":"(Bot) El bot confirma la fecha de nacimiento"},
                123: {"eventName":"servicios_verifica_usuario_cliente"},
                124: {"eventName":"Pregunta S/N para guardar numero telefonico"},
                125: {"eventName":"Lee respuesta numero telefonico"},
                126: {"eventName":"Leer numero telefonico"},
                127: {"eventName":"valida y guarda numero telefonico"},
                128: {"eventName":"Leer a pedir el numero, longitud incorrecta"},
                129: {"eventName":"Vuelve a validar el numero"},
                130: {"eventName":"mostrar_ingresa_domicilio"},
                132: {"eventName":"leer_confirmar_domicilio"},
                133: {"eventName":"mostrar_calle_numero"},
                134: {"eventName":"(Bot) Lee unicamente la calle y el numero por separado"},
                135: {"eventName":"(Bot) El bot lee la colonia por separado"},
                136: {"eventName":"(Bot) Lee el codigo postal por separado"},
                137: {"eventName":"leer_codigo_postal_again"},
                140: {"eventName":"servicios_valida_usuario_beneficiario_listanegra"},
                150: {"eventName":"servicios_cotiza"},
                151: {"eventName":"(BOT) confirma cotizacion y sigue con el proceso de envio"},
                152: {"eventName":"servicios_genera_folio"},
                153: {"eventName":"mostrar_motivo_de_cancelacion"},
                154: {"eventName":"leer_mostrar_motivos_cancelacion"},
                155: {"eventName":"leer_leer_motivo"},
                160: {"eventName":"mostrar_regresa_inicio"},
                170: {"eventName":"servicios_notificacion_activacion_codigo"},
                180: {"eventName":"(Bot) Lee la opción elegida por el usuario para enviar ubicación"},
                250: {"eventName":"mostrar_finish"},
                210: {"eventName":"mostrar_busca_elektra"},
                200: {"eventName":"(Bot) Lee la ubicación enviada por el usuario"},
                220: {"eventName":"(Bot) muetra texto para solicitar monto a cotizar de 20 a 1000"},
                225: {"eventName":"(Bot) Lee el monto a cotizar"},
                226: {"eventName":"leer_confirmar_cotizacion_flujo2"},
                227: {"eventName":"(Bot) Muestra texto de error respecto a la confirmacion dela transacción"},
                251: {"eventName":"Leer numero, numero no valido" }
            }
        eventName = states[message]['eventName']
        print("--------------Parametros Agregados a base de datos----------------------")
        print(eventName)
        self.ora.addMensaje(sender_id,eventName)
        print("------------------------------------------------------------------------")


    def getMessages(self,sender_id,name,last_name,mothers_last_name,motivo="Contacto Dinero Express"):
        payloadMessage = self.ora.consultaMensajes(sender_id)
        print("--------------Parametros de base de datos----------------------")
        print(payloadMessage)
        print("------------------------------------------------------------------------")
        s1Request.sendFirstMessage(sender_id,name,last_name,mothers_last_name,motivo,payloadMessage)

    def validarSalirChat(self,sender_id, message):
        replies = {'CancelarCallCenterS/N':[{"content_type":"text","title":"Si","payload":"CancelarCallCenterS"},
                          {"content_type":"text","title":"No","payload":"CancelarCallCenterN"}]}
        if (message == "CANCELAR_OPERACION"):
            text = "¿Estas seguro que deseas cancelar la conversación con nuestro agente?"
            bot.send_quick_replies(sender_id,text,replies['CancelarCallCenterS/N'])
            return False
        elif (message == "CancelarCallCenterS"):
            s1Request.sendmessage(sender_id,"","","","El usuario cerró la conversación con el agente")
            self.ora.habilitarBot(sender_id, '0')
            replie = [{"content_type":"text","title":"Menú Principal","payload":"Menú Principal"}]
            bot.send_quick_replies(sender_id,"Para realizar alguna operación regresa al menú principal",replie)
            return False
        elif (message == "CONTACTO"):
            text = "En este momento ya te encuentras en contacto con un agente. :D"
            bot.send_text_message(sender_id, text)
            return False
        else:
            return True

    def noAvalible(self,sender_id):
        text = "Lo sentimos , no podemos recibir el adjunto que mandaste , intenta una foto o un video"
        bot.send_text_message(sender_id, text)
