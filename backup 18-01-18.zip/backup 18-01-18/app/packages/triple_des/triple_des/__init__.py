import json
import requests
import pyDes
import base64
import urllib
import urllib.parse
import os
import re
import random
import array


#Clase que contiene los metodos necesarios para la encriptacion de los datos en triple des 
class TRIPLE_DES():

    def genera_llave(self):
        l = 'abcdefghijklmnopqrstuvwxyz'
        k = os.urandom(32)
        key = base64.b64encode(k)
        key = key.decode('utf8')
        key = re.sub('[^a-z|A-Z|0-9]', random.choice(l), key)
        return key
    

    def valida_Llave(self,key):
        if len(key) > 24:
            key = key[:24]
            return key
        if len(key) == 24:
            return key


    def encriptar_3des(self, data, key):
        key = self.valida_Llave(key)
        k = pyDes.triple_des(key, pyDes.ECB, pad=None, padmode=pyDes.PAD_PKCS5)
        try:
            d = k.encrypt(data)
            encoded = base64.b64encode(d)
            decoded = base64.b64decode(encoded)
            encoded = encoded.decode('utf8')
            #print(encoded)
            a = urllib.parse.quote_plus(encoded)
            z = urllib.parse.unquote_plus(a)
        
        except Exception as e:
            print (e)
        return a


    def desencriptar_3des(self, data, key):
        key = self.valida_Llave(key)
        k = pyDes.triple_des(key, pyDes.ECB, pad=None, padmode=pyDes.PAD_PKCS5)
        try:
            z = urllib.parse.unquote_plus(data)
            decoded = base64.b64decode(z)
            d = k.decrypt(decoded)
        except Exception as e:
            print (e)
        return d

    