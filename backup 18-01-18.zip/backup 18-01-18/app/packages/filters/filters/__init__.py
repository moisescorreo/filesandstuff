#! /usr/bin/python
# -*- coding: utf-8 -*-
import _pickle as cPickle
import difflib
import unicodedata
from datetime import datetime, date, time, timedelta
import operator

class FilterDate():
	def filter(fecha):
		try:
			especial_tokens = ["de","del","a"]
			tokens = []

			fecha = fecha.replace("/"," ")
			fecha = fecha.replace("-"," ")
			fecha = fecha.replace("."," ")
			fecha = fecha.replace(","," ")
			fecha = fecha.replace("_"," ")
			list_fecha = fecha.split(" ")
			
			for i in range(len(list_fecha)):
				if list_fecha[i] == '':
					pass
				else: 
					tokens.append(list_fecha[i])

			mes_numer={"ENERO":"01","FEBRERO":"02","MARZO":"03","ABRIL":"04","MAYO":"05",
			"JUNIO":"06","JULIO":"07","AGOSTO":"08","SEPTIEMBRE":"09","OCTUBRE":"10",
			"NOVIEMBRE":"11","DICIEMBRE":"12"}

			names = []
			for token in tokens:
				_token = token.lower()
				if _token in especial_tokens:
					pass
				else:
					names.append(token)
			num_dia = len(names)
			dia,mes,ano,mesN = "","","",""
			if len(names[2])==2 and int(names[2]) > 50:
				names[2] = "19"+str(names[2])
			print(names)

			try: 
				fecha = str(names[0])+"/"+str(names[1])+"/"+str(names[2])
				print(fecha)
				fecha = datetime.strptime(fecha, "%d/%m/%Y").date()
				dia = str(fecha.day)
				mesN = str(fecha.month)
				ano = str(fecha.year)
				for k,v in mes_numer.items():
					if int(mesN)==int(v):
						mes = k
				print(mes)
			except:	
				try:
					dia= names[0]	
					mes=mes_filtro(names[1])
					if len(names[2])==4:
						ano = names[2]
					else:
						return False
					if names[2] == False:
						return False                                                                                                                                                                                                                    
				except:
					return False

			mesN = mes_numer[mes.upper()]
			day1 = datetime.now()
			fechafechaEntrada = datetime(int(ano),int(mesN),int(dia),0,0,0)
			diferencia_dias = (day1 - fechafechaEntrada)

			if int(diferencia_dias.days) < 6570:
				return False
			else:
				return [str(dia+"/"+mes.title()+"/"+ano),str(dia+"/"+mesN+"/"+ano)]
		except:
			return False

def mes_filtro(text):
	text=str(text.lower())
	try:
	    month_dict ={
	    'enero':  		['enero', 'ene', 'january'], 
	    'febrero':  	['febrero', 'feb', 'february'], 
	    'marzo':  		['marzo', 'mar', 'march'], 
	    'abril':  		['abril', 'abr', 'april'], 
	    'mayo':  		['mayo', 'may', 'may'], 
	    'junio':  		['junio', 'jun', 'june'], 
	    'julio':  		['julio', 'jul', 'july'], 
	    'agosto':  		['agosto', 'ago', 'august'], 
	    'septiembre':  	['septiembre', 'sep', 'september'], 
	    'octubre': 		['octubre', 'oct', 'october'], 
	    'noviembre': 	['noviembre', 'nov', 'november'], 
	    'diciembre': 	['diciembre', 'dic', 'december']
	    }
	    month_key = list(month_dict.keys())
	    month_value = list(month_dict.values())
	    month_dict_match = {month_key[i]:difflib.get_close_matches(text, month_value[i]) for i in range(len(month_key))}
	    
	    reduced_month_dict = {k: v for k, v in month_dict_match.items() if v}
	    
	    pct_match = []
	    month_match = {}
	    
	    for i in reduced_month_dict.values():
	        l = difflib.SequenceMatcher(None, text, i[0]).ratio()*100
	        pct_match.append(l)
	        match_dict = {i[0]:l}
	        month_match.update(match_dict)
	 
	    closest_match = max(month_match, key=month_match.get)
	    for month_key, values in month_dict.items():
	        if closest_match in values:
	            return month_key
	except:
		return False


class FilterNames():
	def filter(nombre):
		tokens = nombre.split(" ")
		especial_tokens = ["da","de","di","do","del","la","las","le","los","y","san"]
		names = []
		prev = ""

		for token in tokens:
			_token = token.lower()

			if _token in especial_tokens:
				prev += token + " "
			else:
				names.append(prev + token)
				prev = ""
		
		num_nombres = len(names)
		nombre,appelido1,appelido2 = "","",""

		if num_nombres == 0:
			nombres = ""

		elif num_nombres == 1:
			nombres = names[0]

		elif num_nombres == 2:
			nombres = names[0]
			appelido1 = names[1]

		elif num_nombres == 3:
			nombres = names[0]
			appelido1 = names[1]
			appelido2 = names[2]

		else:
			nombres = names[0] + " " + names [1]
			appelido1 = names[2]
			appelido2 = names[3]
		
		if appelido1=="" or appelido2=="":
			return False

		nombres = nombres.title()
		appelido1 = appelido1.title()
		appelido2 = appelido2.title()

		return [nombres,appelido1,appelido2]


class FilterQuantity():
	def validate(num):
		try:
			num = FilterQuantity.eliminate_words(num.lower())
			if  int(num) >= 20 and int(num) <= 1000:
				num = num.replace(" ","")
				return [True, num]
			else:
				return [False, '0']
		except:
			return FilterQuantity.validate(FilterQuantity.word2int(num))

	def word2int(textnum, numwords={}):
		try:
			if not numwords:
				units = [
				"cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho",
				"nueve", "diez", "once", "doce", "trece", "catorce", "quince",
				"dieciseis", "diecisiete", "dieciocho", "diecinueve",
				]

				tens = ["", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"]

				scales = ["","ciento","doscientos","trescientos","cuatrocientos","quinientos","siescientos","setecientos","ochocientos","novecientos", "mil"]

				numwords["y"] = (1, 0)
				for idx, word in enumerate(units):    numwords[word] = (1, idx)
				for idx, word in enumerate(tens):     numwords[word] = (1, idx * 10)
				for idx, word in enumerate(scales):   numwords[word] = (1, idx * 100)

			current = result = 0
			for word in textnum.split():
				if word =="cien":
					return str(100)
				else:
					if word not in numwords:
						return False

					scale, increment = numwords[word]
					current = current * scale + increment
					if scale > 100:
						result += current
						current = 0
			return str(result + current)
		except:
			return '0'

	def eliminate_words(string_input):
		string_input = string_input.replace("$","")
		string_input = string_input.replace("pesos","")
		string_input = string_input.replace("pesitos","")
		string_input = string_input.replace("morlacos","")
		string_input = string_input.replace("varos","")
		return string_input

class FilterGreetings():
	def filter(text):
		cl = cPickle.load( open( "sources/classifier.pickle", "rb" ) )
		textClass = cl.classify(text.lower())
		if textClass == 'creador':
			return 0
		elif textClass == 'saludo':
			return 1
		else :
			return 2
			pass
		pass

class FilterState():
	def filter(state):
		state = state.title()
		state = ''.join((c for c in unicodedata.normalize('NFD', state) if unicodedata.category(c) != 'Mn'))

		if state == "Cdmx" or state =="Ciudad De Mexico" or state=="Df" or state == "Distrito Federal":
			state="Ciudad De Mexico"
		elif state =="Estado De Mexico" or state == "Edo Mexico":
			state = "Mexico"
		
		estados= ["Aguascalientes","Baja California","Baja California Sur","Campeche","Chiapas","Chihuahua","Coahuila","Colima",
			"Ciudad De Mexico","Durango","Mexico","Guanajuato","Guerrero","Hidalgo","Jalisco","Michoacan","Morelos","Nayarit","Nuevo Leon",
			"Oaxaca","Puebla","Queretaro","Quintana Roo","San Luis Potosi","Sinaloa","Sonora","Tabasco","Tamaulipas",
			"Tlaxcala","Veracruz","Yucatan","Zacatecas"]

		for k in estados:
			if state == k:
				if k =="Mexico" or k =="Ciudad De Mexico":
					k == k.replace("Mexico","México")
					return k
				return k
