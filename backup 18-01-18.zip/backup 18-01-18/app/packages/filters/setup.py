from setuptools import setup

setup(name='filters',
      version='0.1',
      description='filters for bot',
      author='Mariachi IO',
      author_email='raul@mariachi.io',
      packages=['filters'],
      package_data={'filters': ['classifier.pickle']},
      include_package_data=True,
      zip_safe=False)