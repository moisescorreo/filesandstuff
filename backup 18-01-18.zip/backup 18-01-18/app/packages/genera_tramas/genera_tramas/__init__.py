import json
from triple_des import TRIPLE_DES
import datetime

tres_des = TRIPLE_DES()

#Clase que contiene los metodos necesarios para generar las tramas de los diferentes servicios para el metodo de pagos
class GeneraTramas():

    # metodo que asigna la longitud y tipo de operacion a las tramas, ejem salida: 003001 
    def codigos_operacion(self,cod):
        long_tramas = '003'
        cod_final =''
        
        #listado de los codigos de los servicios
        """genera_token = '001', genera_cod_confirmacion ='002', valida_cod_confirmacion = '003',
           registra_cliente_invitado='004', inicia_sesion = '005', agregar_tarjeta = '006',
           consultar_tarjetas = '007', eliminar_tarjeta = '008', valida_referencia_ps = '009',
           registra_pago_servicios = '010', consulta_movimiento = '011' """

        dic_services = {1:'001',2:'002',3:'003',4:'004', 5:'005',6:'006',7:'007',
                        8:'008',9:'009',10:'010',11:'011'}

        codigo = dic_services.get(cod)
        cod_final = long_tramas+codigo
        return cod_final

    # metodo que agrega la longitud en formato de la trama  dada a una cadena ejm: 0000200
    def long_datos(self,cadena):
        llave = '0'
        datos = '00000'

        if len(cadena) <= 55:
            llave_long = llave+str(len(cadena))
            return llave_long
        else:
            if len(cadena) > 99:
                datos='0000'
                datos_long = datos+str(len(cadena))
                return datos_long
            else:
                datos_long = datos+str(len(cadena))
                return datos_long
    
    
    #genera los datos de la trama en un dicionario, que seran codificados en 3DES para cada servicio
    def text_message(self,**kwargs):
        #print(kwargs)
        #print()
        tipo_op = kwargs.get("tipo_op")
       
        #genera_token y genera_cod_confirmacion
        if tipo_op < 3 :
            numeroTelefono = str(kwargs.get("numeroTelefono"))
            message_data ={
                "numeroTelefono":numeroTelefono,
                "idPais":"1",
                "idCanal":"3"
                }
            data=json.dumps(message_data)
            #print(data)
            return data

        #servicio valida_cod_confirmacion
        elif tipo_op == 3:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            codigoConfirmacion =kwargs.get("codigoConfirmacion")
            message_data ={
                "numeroTelefono":numeroTelefono,
                "idPais":"1",
                "idCanal":"3",
                "codigoConfirmacion":codigoConfirmacion
                }
            data=json.dumps(message_data)
            print(data)
            return data 

        #registra_cliente_invitado
        elif tipo_op == 4:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            nickName =kwargs.get("nickName")
            email =kwargs.get("email")
            contrasenia =kwargs.get("contrasenia")
            message_data ={
                "numeroTelefono":numeroTelefono,
                "idPais":"1",
                "idCanal":"3",
                "token":token,
                "nickName":nickName,
                "email":email,
                "contrasenia":contrasenia
                }
            data=json.dumps(message_data)
            print(data)
            return data

        #inicia_sesion
        elif tipo_op == 5:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            #password =kwargs.get("password")
            contrasenia =kwargs.get("contrasenia")
            message_data ={
                "numeroTelefono":numeroTelefono,
                "idPais":"1",
                "idCanal":"3",
                "token":token,
                #"password":password
                "contrasenia":contrasenia
                }
            data=json.dumps(message_data)
            print(data)
            return data


        #agregar_tarjeta
        elif tipo_op == 6:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            nombreTarjeta =kwargs.get("nombre")
            email =kwargs.get("email")
            password =kwargs.get("contrasenia")
            apMaternoTarjeta =kwargs.get("apMaternoTarjeta")
            apPaternoTarjeta =kwargs.get("apPaternoTarjeta")
            codigoSesion =kwargs.get("codigoSesion")
            numTarjeta =kwargs.get("numTarjeta")
            fechaExpTarjeta =kwargs.get("fechaExpTarjeta")
            #latitud =kwargs.get("latitud")
            #longitud =kwargs.get("longitud")
            validadorTarjeta =kwargs.get("validadorTarjeta")

            message_data ={
                "apMaternoTarjeta":apMaternoTarjeta,
                "apPaternoTarjeta":apPaternoTarjeta,
                "codigoSesion":codigoSesion,
                "fechaExpTarjeta":fechaExpTarjeta,
                "idCanal":"3",
                "idPais":"1",
                "latitud":"00.000000",
                "longitud":"-00.00000000",
                "nombreTarjeta":nombreTarjeta,
                "numTarjeta":numTarjeta,
                "numeroTelefono":numeroTelefono,
                "token":token,
                "validadorTarjeta":validadorTarjeta
                }
            data=json.dumps(message_data)
            print(data)
            return data


        #Consultar Tarjetas
        elif tipo_op == 7:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            codigoSesion = kwargs.get("codigoSesion")
            message_data ={
                "numeroTelefono":numeroTelefono,
                "idPais":"1",
                "idCanal":"3",
                "token":token,
                "codigoSesion":codigoSesion
                }
            data=json.dumps(message_data)
            print(data)
            return data
        

        #eliminar_tarjeta
        elif tipo_op == 8:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            codigoSesion = kwargs.get("codigoSesion")
            tarjetaId = kwargs.get("tarjetaId")
            message_data ={
                "numeroTelefono":numeroTelefono,
                "tarjetaId": tarjetaId,
                "idPais":"1",
                "idCanal":"3",
                "token":token,
                "codigoSesion":codigoSesion
                }
            data=json.dumps(message_data)
            print(data)
            return data


        #valida_referencia_ps
        elif tipo_op == 9:
            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            importe = kwargs.get("importe")
            referencia = kwargs.get("referencia")
            codigoSesion = kwargs.get("codigoSesion")
            message_data ={
                "importe": importe,
                "numeroTelefono": numeroTelefono,
                "idPais": "1",
                "token": token,
                "idCanal": "3",
                "emisorId": "66",
                "referencia": referencia,
                "codigoSesion":codigoSesion
            }
            data=json.dumps(message_data)
            print(data)
            return data


        #registra_pago_servicios
        elif tipo_op == 10:
            currentDT = datetime.datetime.now()
            UID = currentDT.strftime("%d%m%y%H%M%S")
            
            codigoSesion =str(kwargs.get("codigoSesion"))
            comision =kwargs.get("comision")
            importe = kwargs.get("importe")
            emisorId = kwargs.get("emisorId")
            idEmisorSwitch = kwargs.get("idEmisorSwitch")
            idTarjeta = kwargs.get("idTarjeta")
            iva = kwargs.get("iva")
            #latitud = kwargs.get("latitud")
            #longitud = kwargs.get("longitud")
            montoPago = kwargs.get("montoPago")
            montoTotal = kwargs.get("montoTotal")
            numeroTelefono = kwargs.get("numeroTelefono")
            parametros = kwargs.get("parametros")
            referencia = kwargs.get("referencia")
            referenciaSwitch = kwargs.get("referenciaSwitch")
            token = kwargs.get("token")
            #uid = UID,
            validadorTarjeta = kwargs.get("validadorTarjeta")
            message_data ={
                "adicionales":"",
                "codigoSesion":codigoSesion,
                "comision":comision,
                "especiales":"",
                "idCanal":"3",
                "idEmisorSwitch":idEmisorSwitch,
                "idMedioPago":"3",
                "idPais":"1",
                "idTarjeta":idTarjeta,
                "iva":iva,
                "latitud":"00.000000",
                "longitud":"-00.00000000",
                "montoPago":montoPago,
                "montoTotal":montoTotal,
                "numeroTelefono": numeroTelefono,
                "parametros":parametros,
                "referencia":referencia,
                "referenciaSwitch":referenciaSwitch,
                "token": token,
                "uid": UID,
                "validadorTarjeta":validadorTarjeta
            } 
            data=json.dumps(message_data)
            print(data)
            return data


        #consulta_movimiento
        elif tipo_op == 11:
            currentDT = datetime.datetime.now()
            fechaMov = currentDT.strftime("%d/%m/%Y")

            numeroTelefono =str(kwargs.get("numeroTelefono"))
            token =kwargs.get("token")
            montoPago = kwargs.get("montoPago")
            emisorId = kwargs.get("emisorId")
            referencia = kwargs.get("referencia")
            uid = kwargs.get("uid")
            idEmisorSwitch = kwargs.get("idEmisorSwitch")
            referenciaSwitch = kwargs.get("referenciaSwitch")
            #fechaMov = kwargs.get("fechaMov")
            message_data ={
                "uid":uid,
                "numeroTelefono":numeroTelefono,
                "montoPago":montoPago,
                "idPais":"1",
                "token":token,
                "idEmisorSwitch":idEmisorSwitch,
                "referenciaSwitch":referenciaSwitch,
                "idCanal":"3",
                "fechaMov":fechaMov
            } 
            data=json.dumps(message_data)
            print(data)
            return data


    #metodo que arma la trama de datos a enviar para cada uno de los servicios 
    def crea_trama(self,**kwargs):
        tipo_operacion = kwargs.get("tipo_op")
        
        if tipo_operacion > 0 and tipo_operacion <= 11:

            #generamos la llave para el triple_des
            llave_3des = tres_des.genera_llave()
            #print(llave_3des)
        
            #Algunos servicios requieren doble encriptacion 3Des en algunos campos como pass o datos de la tarjeta aqui los encriptamos 
            if tipo_operacion == 4:
                con = kwargs.get("contrasenia")
                contrasenia1 = tres_des.encriptar_3des(con,llave_3des)
                kwargs["contrasenia"]=contrasenia1
                print(kwargs)
               
            elif tipo_operacion == 5:
                con = kwargs.get("contrasenia")
                #print(con)
                contrasenia1 = tres_des.encriptar_3des(con,llave_3des)
                #print(contrasenia1)
                kwargs["contrasenia"]=contrasenia1
                print(kwargs)

            elif tipo_operacion == 6:
                num_tarjeta = kwargs.get("numTarjeta")
                fecha_epx = kwargs.get("fechaExpTarjeta")
                cod_vali = kwargs.get("validadorTarjeta")

                num_tar = tres_des.encriptar_3des(num_tarjeta,llave_3des)
                exp = tres_des.encriptar_3des(fecha_epx,llave_3des)
                cod = tres_des.encriptar_3des(cod_vali,llave_3des)

                kwargs["numTarjeta"]=num_tar
                kwargs["fechaExpTarjeta"]=exp
                kwargs["validadorTarjeta"]=cod
                print(kwargs)

            elif tipo_operacion == 10:
                validador = kwargs.get("validadorTarjeta")
                #print(validador)
                validadorTarjeta = tres_des.encriptar_3des(validador,llave_3des)
                #print(validadorTarjeta)
                kwargs["validadorTarjeta"]=validadorTarjeta
                print(kwargs)

            #Arma la longitud1 y los datos1 de la trama
            long1_datos1 = self.codigos_operacion(tipo_operacion)
            #print(long1_datos1)

            #Arma la longitud2 y los datos2 de la trama
            datos = self.text_message(**kwargs)
        
            datos2_3des = tres_des.encriptar_3des(datos,llave_3des)
            #print(datos2_3des)
            longitud_datos2=self.long_datos(datos2_3des)
            #print(longitud_datos2)
            long2_datos2 = longitud_datos2+datos2_3des
            #print(long2_datos2)

            #Arma la lon3 y datos3 de la trama
            longitud_datos3=self.long_datos(llave_3des)
            long3_datos3=longitud_datos3+llave_3des
            #print(long3_datos3)
            trama_final=long1_datos1+long2_datos2+long3_datos3
            print(trama_final)
            return trama_final
        else:
            text="El codigo de operacion ingresado no existe en el dic de servicios"
            print('***********************************')
            print("El codigo de operacion ingresado no existe en el dic de servicios")
            print('***********************************')
            return text

        
