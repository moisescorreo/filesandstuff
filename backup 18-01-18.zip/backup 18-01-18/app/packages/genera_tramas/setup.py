from setuptools import setup

setup(name='genera_tramas',
      version='0.1',
      description='genera_tramas',
      author='Plincos',
      author_email='aldo@plincos.com',
      packages=['genera_tramas'],
      zip_safe=False)