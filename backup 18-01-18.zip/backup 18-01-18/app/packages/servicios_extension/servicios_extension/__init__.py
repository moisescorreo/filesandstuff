import json
import requests
from datetime import datetime
import os
from genera_tramas import GeneraTramas


tramas = GeneraTramas()

URL_GENERICA_EXTENSION = os.environ["URL_EXTENSION"]

#clase que contiene los servicios para el metodo de pago con tarjetas C/D
class URL_Services():

    #retorna un token Z213CLW8VQ
    def genera_token(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"clientes/generaToken"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers ,verify=False,timeout=10)
            print(response.text)
            payload = response.json()

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['detalleMensaje'])
                data = payload['datosSalida']
                token = data.get("token")
                return token
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                #print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")

        
    #retorna 1 que indica exito en la operacion
    def genera_cod_confirmacion(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"clientes/generaCodigoConfirmacion"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=10)
            payload = response.json()

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['detalleMensaje'])
                cod_op = payload['codigoOperacion']
                
                return cod_op
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return tipoMensaje
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


    #retorna 1 que indica exito en la operacion
    def valida_cod_confirmacion(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"clientes/validaCodigoConfirmacion"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers ,verify=False,timeout=10)
            payload = response.json()

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['mensaje'])
                cod_op = payload['codigoOperacion']
                
                return cod_op
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")

    
    #retorna 1 que indica exito en la operacion
    def registra_cliente_invitado(self,trama):
        #print(trama)
        try:
            url = URL_GENERICA_EXTENSION+"clientes/registraClienteInvitado"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=10)
            print(response.text)
            payload = response.json()
            #payload = json.loads(payload)

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['mensaje'])
                cod_op = payload['codigoOperacion']
                
                return cod_op
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                detalleMensaje =payload['detalleMensaje']
                text=mensaje+" "+tipoMensaje+" "+detalleMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


    #Regresa un "codigoSesion":"LYU8ENRUV6WJRBXF2XL1" 
    def inicia_sesion(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"clientes/iniciaSesion"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=10)
            print(response.text)
            payload = response.json()

            if response.status_code == 200 and payload["codigoOperacion"]==1:
                print(payload['mensaje'])
                cod_op = payload['codigoOperacion']

                a = payload.get("datosSalida")
                codigo_sesion = a['codigoSesion']
                
                return codigo_sesion
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


    #retorna 1 que indica exito en al operacion
    def agregar_tarjeta(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"tarjetas/agregarTarjeta"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=10)
            payload = response.json()
            print(response.text)
            if response.status_code == 200 and payload["codigoOperacion"]==1:
                print(payload['mensaje'])
                cod_op = payload['codigoOperacion']
                return cod_op
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


    #regresa una lista de las tarjetas del usuario
    '''{'tarjetas': 
        [{'tarjetaId': 3, 'mascara': '4307', 'fechaExpira': '12/17', 'tipoTarjeta': 'DEBITO', 'marcaTarjeta': 'MASTER CARD', 'banco': 'AZTECA'},
         {'tarjetaId': 2, 'mascara': '0481', 'fechaExpira': '10/17', 'tipoTarjeta': 'DEBITO', 'marcaTarjeta': 'MASTER CARD', 'banco': 'AZTECA'}]}'''
    def consultar_tarjetas(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"tarjetas/consultaTarjetas"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=15)
            payload = response.json()

            if response.status_code == 200 and payload["codigoOperacion"]==1:
                print(payload['mensaje'])
                a = payload.get("datosSalida")
                list_tarjetas = a['tarjetas']

                return list_tarjetas
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has filed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


    #retorna 1 que indica exito en al operacion
    def eliminar_tarjeta(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"tarjetas/eliminaTarjeta"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=15)
            payload = response.json()
            print(payload)
            if response.status_code == 200 and payload['codigoOperacion']==1:
                
                mensaje = payload['mensaje']
                print(mensaje)
                cod_op = payload['codigoOperacion']
                return cod_op
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


        #devuelve un diccionario 
        '''{'comisiones': [{'nombre': 'comisionCliente', 'valor': '0.00'}, {'nombre': 'iva', 'valor': '0.00'}], 'especiales': '<att><color>RED<\\/color><cue
        nta>1.454544<\\/cuenta><customer>545485<\\/customer><saldo>253.25<\\/saldo><DN/><\\/att>', 'idEmisorSwitch': '367', 'parametros': '|switchCon:2~r
        etencion:1~cuentaConcentra:00419500000043~cobraComision:0~sucursalid:1~canalid:2028~cekt:7.0~importe:30.0~idemisor:367~cliente:OMAR CEJA~referenc
        ia:00000003174~ivaemisor:1.12', 'referenciaSwitch': '00000003174'}'''
    def valida_referencia_ps(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"operaciones/validaReferenciaPS"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=15)
            payload = response.json()

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['mensaje'])
                datos_salida = payload.get("datosSalida")
                return datos_salida
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


        '''{'folioPDD': '12008', 'legales': 'Intra Mexicana SA de CV AVV FFCC DEL RIO FRIO 419 AM INDUSTRIAL DEL MORAL DISTRITO FEDERAL 09010 Pago registrad
        o por Intra Mexicana y operado por Elektra Express. Dudas y aclaraciones sobre su pago, favor de comunicarse al 01800-050-3333 Al recibir su comp
        robante favor de verificar que los datos de su pago sean correctos. Importante: Conserve su comprobante de pago para futuras aclaraciones', 
        'uid': '091117020543'}'''
    def registra_pago_servicios(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"operaciones/registraPagoServicio"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False,timeout=15)
            payload = response.json()

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['mensaje'])
                datos_salida = payload.get("datosSalida")
                return datos_salida
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")


    '''{'uid': '110917071435', 'emisorId': '48', 'emisor': 'TELMEX', 'montoPago': '250.0', 'folioPDD': '5500',
       'referenciaUsuario': '24848267617', 'comision': '6.03', 'iva': '0.96', 'montoTotal': '256.99', 
       'estatus': 'OPERACION EXITOSA', 'fecha': '11/09/2017'}'''
    def consulta_movimiento(self,trama):
        try:
            url = URL_GENERICA_EXTENSION+"operaciones/consultaMovimiento"
            payload = {"trama":trama}
            headers = {"content-type": "application/json"}
            response = requests.post(url, json = payload, headers = headers , verify=False, timeout=15)
            payload = response.json()
            print('=======')
            print(payload)
            print(response.status_code)

            if response.status_code == 200 and payload['codigoOperacion']==1:
                print(payload['mensaje'])
                datos_salida = payload.get("datosSalida")
                return datos_salida
            else:
                mensaje =payload['mensaje']
                tipoMensaje =payload['tipoMensaje']
                text=mensaje+" "+tipoMensaje
                print(text)
                return text
        except ValueError:
            print('Decoding JSON has failed')
            print('Server status: {}'.format(response.status_code))
        except requests.exceptions.Timeout:
            print("Timeout occurred after 10s waiting")

