#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests
import json
import traceback
import time
import os
import sys
from PIL import Image
import io
from io import BytesIO


os.environ["NLS_LANG"] = ".AL32UTF8"

import cx_Oracle

class Orabd():
	def __init__(self):
		self.userBD = os.environ['USER_DB']
		self.passDB = os.environ['PASS_DB']
		self.serviceDB = os.environ['SERVICE_DB']
		self.db_pool = self.conexion()

	def cathErrores(var):
		def handle_function(func):
			def handle_error(self, *args, **kwargs):
				try:
					result = func(self, *args, **kwargs)
				except cx_Oracle.DatabaseError as e:
					error, = e.args
					fecha = self.getFechaHora()
					connection = self.db_pool.acquire()
					cursorinsert = connection.cursor()
					cursorinsert.prepare("INSERT INTO CHATBOT.TAERRORES VALUES(CHATBOT.SEIDERRORES.NEXTVAL, TO_DATE(:fecha ,'DD/MM/YYYY HH24:MI:SS'), :codigo, :error)")
					cursorinsert.execute(None, {"fecha": fecha, "codigo": error.code, "error": var + str(error.message)})
					connection.commit()
					cursorinsert.close()
					self.db_pool.release(connection)
					return False
				except Exception as e:
					return False
				return result
			return handle_error
		return handle_function

	@cathErrores("init")
	def conexion(self):
		return cx_Oracle.SessionPool(self.userBD,self.passDB,self.serviceDB, 1, 100, 1, threaded = True)

	@cathErrores("Función valida Usuario: ")
	def validaUsuario(self, idUsuario, token_page=None):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FCNOMBRE, FCAPPATERNO, FCAPMATERNO, FCDISPONIBLE FROM CHATBOT.TAUSUARIOS WHERE FINOIDFACEBOOK = :idUser")
		result = cursor.execute(None, {'idUser': idUsuario})
		result_list = result.fetchall()
		nombre = ""
		apPaterno = ""
		apMaterno = ""
		disponible = ""
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				nombre = str(row[0])
				apPaterno = str(row[1])
				apMaterno = str(row[2])
				disponible = str(row[3])
		else :
			userTempData = self.obtenerDatosPublicos(idUsuario,token_page)
			if len(userTempData) > 0: #El usuario puede tener privado sus datos personales {}
				nombre = userTempData['first_name']
				apPaterno = userTempData['last_name']
			cursorinsert = connection.cursor()
			cursorinsert.prepare("INSERT INTO CHATBOT.TAUSUARIOS(FINOIDFACEBOOK, FCNOMBRE, FCAPPATERNO) VALUES (:idUser, :nombre, :apPaterno)")
			cursorinsert.execute(None, {'idUser': idUsuario, 'nombre': nombre, 'apPaterno': apPaterno})
			connection.commit()
			cursorinsert.close()
		data = {"nombre": nombre, "apPaterno": apPaterno, "apMaterno": apMaterno, "disponible": disponible}
		data = json.dumps(data)
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(data)

	@cathErrores("Habilitar bot/callCenter: ")
	def habilitarBot(self, idUsuario, bandera):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FCDISPONIBLE = :bandera WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None,{"bandera": bandera, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Extras: ")
	def consultaDisponibleS1(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FCDISPONIBLE FROM CHATBOT.TAUSUARIOS WHERE FINOIDFACEBOOK = :idUsuario")
		result = cursor.execute(None, {'idUsuario': idUsuario})
		result_list = result.fetchall()
		data = None
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				disponible = str(row[0])
				data = {"disponible": disponible}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función mensaje usuario: ")
	def addMensaje(self, idUsuario, message):
		connection = self.db_pool.acquire()
		fechModificado = self.getFechaHora()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TAMESSAGE VALUES(TO_DATE(:fecha ,'DD/MM/YYYY HH24:MI:SS'), :idUser, :message)")
		cursorinsert.execute(None, {"idUser": idUsuario, "fecha": fechModificado, "message": message})
		connection.commit()
		cursorinsert.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta mensajes usuario: ")
	def consultaMensajes(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT TO_CHAR(FDFECHA, 'DD/MM/YYYY HH24:MI:SS'), FCMESSAGE FROM CHATBOT.TAMESSAGE WHERE FINOIDFACEBOOK = :idUsuario ORDER BY 1 DESC FETCH FIRST 10 ROWS ONLY") 
		result = cursor.execute(None, {'idUsuario': idUsuario})
		result_list = result.fetchall()
		data = []
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				fecha = str(row[0])
				message = str(row[1])
				info = {'fecha': fecha, 'message': message}
				data.append(info)
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))


	@cathErrores("Función consulta Estado: ")
	def consultaEstado(self, idUsuario, tipoEstado=None):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FDFECHA, FIESTANTERIOR, FIESTACTUAL, FCTIPO FROM CHATBOT.TAESTADOS WHERE FINOIDFACEBOOK = :idUser")
		result = cursor.execute(None, {'idUser': idUsuario})
		result_list = result.fetchall()
		fechModificado = self.getFechaHora()
		estAnterior = 10
		estActual = 10
		tipo = 'L'
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				fechModificado = str(row[0])
				estAnterior = row[1]
				estActual = row[2]
				tipo = str(row[3])
		else :
			cursorinsert = connection.cursor()
			cursorinsert.prepare("INSERT INTO CHATBOT.TAESTADOS VALUES (TO_DATE(:fecha ,'DD/MM/YYYY HH24:MI:SS'), :estAnterior, :estActual, :idUser, :tipo)")
			cursorinsert.execute(None, {"fecha": fechModificado, "estAnterior": estAnterior, "estActual": estActual, "tipo": tipo, "idUser": idUsuario})
			connection.commit()
			cursorinsert.close()
		data = {"fechaModificado": fechModificado, "estAnterior": estAnterior, "estActual": estActual, "tipo": tipo}
		data = json.dumps(data)
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(data)

	@cathErrores("Función update Estado: ")
	def updateEstado(self, idUsuario, estSiguiente, tipoEstado=None):
		connection = self.db_pool.acquire()
		fechModificado = self.getFechaHora()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TTESTACTUAL VALUES(:idUser, TO_DATE(:fecha ,'DD/MM/YYYY HH24:MI:SS'), :estActual, :tipo)")
		cursorinsert.execute(None, {"idUser": idUsuario, "fecha": fechModificado, "estActual": estSiguiente, "tipo": tipoEstado})
		connection.commit()
		cursorinsert.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Nombre Usuario: ")
	def updateNombreUsuario(self, idUsuario, nombre, apPaterno=None, apMaterno=None):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FCNOMBRE = :nombre, FCAPPATERNO = :apPaterno, FCAPMATERNO = :apMaterno WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"nombre": nombre, "apPaterno": apPaterno, "apMaterno": apMaterno, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Id Cliente Usuario: ")
	def updateIdClienteUsuario(self, idUsuario, idCliente):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FINOIDCLIENTE = :idCliente WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"idCliente": idCliente, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Fecha Nac Usuario: ")
	def updateFechaNacUsuario(self, idUsuario, fechaNac):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FDFECHANAC = TO_DATE(:fecha ,'DD/MM/YYYY') WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"fecha": fechaNac, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Telefono Usuario: ")
	def updateTelefonoUsuario(self, idUsuario, telefono):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FITELEFONO = :telefono WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"telefono": telefono, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Lista Negra: ")
	def updateListaNegra(self, idUsuario, listaNegra):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FIBLOQUEO = :listaNegra WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"listaNegra": listaNegra, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Direccion Usuario: ")
	def updateDireccionUsuario(self, idUsuario, direccion, cp=None, estado=None, municipio=None, colonia=None):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FCDIRECCION = :direccion, FICODPOSTAL = :cp, FCESTADO = :estado, FCMUNICIPIO = :municipio, FCCOLONIA = :colonia WHERE FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"direccion": direccion, "cp":  cp, "estado": estado, "municipio": municipio, "colonia": colonia, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Datos Usuario: ")
	def consultaDatosUsuario(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FINOIDCLIENTE, FCNOMBRE, FCAPPATERNO, FCAPMATERNO, TO_CHAR(FDFECHANAC ,'DD/MM/YYYY'), FIBLOQUEO, FITELEFONO, FCDIRECCION, LPAD(TO_CHAR(FICODPOSTAL), 5, '0'), FCESTADO, FCMUNICIPIO, FCCOLONIA FROM CHATBOT.TAUSUARIOS WHERE FINOIDFACEBOOK = :idUser")
		result = cursor.execute(None, {'idUser': idUsuario})
		result_list = result.fetchall()
		nombre = ""
		apPaterno = ""
		apMaterno = ""
		idCliente = 0
		fechaNac = ""
		bloqueo = 0
		telefono = 0
		direccion = ""
		cp = 0
		estado = ""
		municipio = ""
		colonia = ""
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				idCliente = row[0]
				nombre = str(row[1])
				apPaterno = str(row[2])
				apMaterno = str(row[3])
				fechaNac = str(row[4])
				bloqueo = row[5]
				telefono = str(row[6])
				direccion = str(row[7])
				cp = str(row[8])
				estado = str(row[9])
				municipio = str(row[10])
				colonia = str(row[11])
		data = {"idCliente": idCliente, "nombre": nombre, "apPaterno": apPaterno, "apMaterno": apMaterno, "fechaNac": fechaNac, "bloqueo": bloqueo, "telefono": telefono, "direccion": direccion, "cp": cp, "estado": estado, "municipio": municipio, "colonia": colonia}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función add Beneficiario: ")
	def addBeneficiario(self, idUsuario, idBeneficiario, nombre, apPaterno, apMaterno, telefono=None):
		connection = self.db_pool.acquire()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TABENEFICIARIOS(FINOBENEFICIARIO, FCNOMBRE, FCAPPATERNO, FCAPMATERNO, FITELEFONO, FINOIDFACEBOOK) VALUES(:idBeneficiario, :nombre, :apPaterno, :apMaterno, :telefono, :idUsuario)")
		cursorinsert.execute(None, {"idBeneficiario": idBeneficiario, "nombre": nombre, "apPaterno": apPaterno, "apMaterno": apMaterno, "telefono": telefono, "idUsuario": idUsuario})
		connection.commit()
		cursorinsert.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Entidad Beneficiario: ")
	def updateEntidadBeneficiario(self, idUsuario, idBeneficiario, entidad):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TABENEFICIARIOS SET FIESTADOID = (SELECT FIESTADOID FROM CHATBOT.TAMAPESTADOS WHERE UPPER(FCNOMBRE) LIKE UPPER(:estado)) WHERE FINOBENEFICIARIO = :idBeneficiario AND FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"idBeneficiario": idBeneficiario, "idUser": idUsuario, "estado": entidad})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Beneficiarios: ")
	def consultaBeneficiarios(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT B.FINOBENEFICIARIO, B.FCNOMBRE, B.FCAPPATERNO, B.FCAPMATERNO, B.FITELEFONO, E.FCNOMBRE FROM CHATBOT.TABENEFICIARIOS B INNER JOIN CHATBOT.TAMAPESTADOS E ON B.FIESTADOID = E.FIESTADOID WHERE b.FINOIDFACEBOOK = :idUser AND B.FIACTIVO = 1")
		result = cursor.execute(None, {'idUser': idUsuario})
		result_list = result.fetchall()
		data = []
		if result.rowcount != 0:
			conta = 0
			for row in result_list:  # get data in row
				if conta < 10:
					conta = conta + 1
					idBeneficiario = row[0]
					nombre = str(row[1])
					apPaterno = str(row[2])
					apMaterno = str(row[3])
					telefono = str(row[4])
					estado = str(row[5])
					info = {"idBeneficiario": idBeneficiario, "nombre": nombre, "apPaterno": apPaterno, "apMaterno": apMaterno, "telefono": telefono, "estado": estado}
					data.append(info)
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función consulta Un Beneficiario: ")
	def consultaUnBeneficiario(self, idUsuario, idBeneficiario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT B.FINOBENEFICIARIO, B.FCNOMBRE, B.FCAPPATERNO, B.FCAPMATERNO, B.FITELEFONO, E.FCNOMBRE FROM CHATBOT.TABENEFICIARIOS B INNER JOIN CHATBOT.TAMAPESTADOS E ON B.FIESTADOID = E.FIESTADOID WHERE (B.FINOBENEFICIARIO = :idBeneficiario AND B.FINOIDFACEBOOK = :idUser) AND B.FIACTIVO = 1")
		result = cursor.execute(None, {'idBeneficiario': idBeneficiario, "idUser": idUsuario})
		result_list = result.fetchall()
		data = {}
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				idBeneficiario = row[0]
				nombre = str(row[1])
				apPaterno = str(row[2])
				apMaterno = str(row[3])
				telefono = str(row[4])
				estado = str(row[5])
				data = {"idBeneficiario": idBeneficiario, "nombre": nombre, "apPaterno": apPaterno, "apMaterno": apMaterno, "telefono": telefono, "estado": estado}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función elimina Beneficiario: ")
	def eliminaBeneficiario(self, idUsuario, idBeneficiario):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TABENEFICIARIOS SET FIACTIVO = 0 WHERE FINOBENEFICIARIO = :idBeneficiario AND FINOIDFACEBOOK = :idUser")
		cursorupdate.execute(None, {"idBeneficiario": idBeneficiario, "idUser": idUsuario})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función genera Uid: ")
	def generaUid(self):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		result = cursor.execute("SELECT 'UID' || 9559 || LPAD(CHATBOT.SEUIDCONSECUTIVO.NEXTVAL, 8, '0')  FROM DUAL")
		result_list = result.fetchall()
		data = 0
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				consecutivo = row[0]
		data = {"uid": consecutivo}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función add Envio: ")
	def addEnvio(self, fcuid, folio, tarifa, descuentoCF, monto, saldoAbonado, tcfx, descuentoCupon, claveSeguridad, montoTotal, montoEnvioMg, referenciaPreEnvio, idBeneficiario, codigo, mensaje):
		connection = self.db_pool.acquire()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TTFOLIOS VALUES(:fcuid, :folio, :tarifa, :descuentoCF, :monto, :saldoAbonado, :tcfx, :descuentoCupon, :claveSeguridad, :montoTotal, :montoEnvioMg, :referenciaPreEnvio, :idBeneficiario, :codigo, :mensaje)")
		cursorinsert.execute(None, {"fcuid": fcuid, "folio": folio, "tarifa": tarifa, "descuentoCF": descuentoCF, "monto": monto, "saldoAbonado": saldoAbonado, "tcfx": tcfx, "descuentoCupon": descuentoCupon, "claveSeguridad": claveSeguridad, "montoTotal": montoTotal, "montoEnvioMg": montoEnvioMg, "referenciaPreEnvio": referenciaPreEnvio, "idBeneficiario": idBeneficiario, "codigo": codigo, "mensaje": mensaje})
		connection.commit()
		cursorinsert.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Envio: ")
	def updateEnvio(self, folio, codigo, mensaje):
		connection = self.db_pool.acquire()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TTUPDATEENVIO VALUES(:folio, :codigo, :mensaje)")
		cursorinsert.execute(None, {"folio": folio, "codigo": codigo, "mensaje": mensaje})
		connection.commit()

		cursor = connection.cursor()
		cursor.prepare("SELECT U.FINOIDFACEBOOK, B.FCNOMBRE, B.FCAPPATERNO || ' ' || B.FCAPMATERNO, U.FCNOMBRE, U.FCAPPATERNO || ' ' || U.FCAPMATERNO, E.FCNOMBRE, T.FIMONTO, T.FCTARIFA, (T.FIMONTOTOTAL - T.FCTARIFA) - T.FIMONTO ,T.FIMONTOTOTAL FROM CHATBOT.TATRANSACCIONES T INNER JOIN CHATBOT.TABENEFICIARIOS B ON (T.FINOBENEFICIARIO = B.FINOBENEFICIARIO) INNER JOIN CHATBOT.TAMAPESTADOS E ON (B.FIESTADOID = E.FIESTADOID) INNER JOIN CHATBOT.TAUSUARIOS U ON (B.FINOIDFACEBOOK = U.FINOIDFACEBOOK) WHERE FIFOLIO = :folio")
		result = cursor.execute(None, {'folio': folio})
		result_list = result.fetchall()
		data = {}
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				idSender = row[0]
				beneficiaryName = str(row[1])
				beneficiaryLastName = str(row[2])
				userName = str(row[3])
				userLastName = str(row[4])
				destiny = str(row[5])
				quantity = row[6]
				tarifa = row[7]
				civa = row[8]
				quantityT = row[9]
				data = {"idSender": idSender, "beneficiaryName": beneficiaryName, "beneficiaryLastName": beneficiaryLastName, "userName": userName, "userLastName": userLastName, "destiny": destiny, "quantity": quantity, "tarifa": tarifa, "civa": civa, "quantityT": quantityT}
		else :
			return False
		cursor.close()
		cursorinsert.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función update Localizacion: ")
	def updateLocalizacion(self, folio, latitud, longitud):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TATRANSACCIONES SET FILATITUDE = :latitud, FILONGITUDE = :longitud WHERE FIFOLIO = :folio")
		cursorupdate.execute(None, {"latitud": latitud, "longitud":  longitud, "folio": folio})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función add Extra: ")
	def addExtra(self, idUser, clave, valor):
		connection = self.db_pool.acquire()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TAEXTRAS VALUES(:idUsuario, :clave, :valor)")
		cursorinsert.execute(None, {"idUsuario": idUser, "clave": clave, "valor": valor})
		connection.commit()
		cursorinsert.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Extras: ")
	def consultaExtras(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FCCLAVE, FCVALOR FROM CHATBOT.TAEXTRAS WHERE FINOIDFACEBOOK = :idUsuario")
		result = cursor.execute(None, {'idUsuario': idUsuario})
		result_list = result.fetchall()
		data = {}
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				clave = str(row[0])
				valor = str(row[1])
				data[clave] = valor
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función elimina Extras: ")
	def eliminaExtras(self, idUsuario):
		connection = self.db_pool.acquire()
		cursordelete = connection.cursor()
		cursordelete.prepare("DELETE FROM CHATBOT.TAEXTRAS WHERE FINOIDFACEBOOK = :idUsuario")
		cursordelete.execute(None, {"idUsuario": idUsuario})
		connection.commit()
		cursordelete.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Extra: ")
	def updateExtra(self, idUsuario, clave, nuevoValor):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAEXTRAS SET FCVALOR = :valor WHERE FINOIDFACEBOOK = :iduser AND FCCLAVE = :clave")
		cursorupdate.execute(None, {"valor": nuevoValor, "iduser": idUsuario, "clave": clave})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Codigo Postal: ")
	def consultaCodigoPostal(self, codigoPostal):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FCCP, FCMUNICIPIO, FCNOMBRE FROM CHATBOT.TAMAPCPOSTAL INNER JOIN CHATBOT.TAMAPESTADOS ON FIIDESTADO = FIESTADOID WHERE FCCP = :cp")
		result = cursor.execute(None, {'cp': codigoPostal})
		result_list = result.fetchall()
		data = {}
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				cp = str(row[0])
				municipio = str(row[1])
				estado = str(row[2])
				data = {"cp": cp, "municipio": municipio, "estado": estado}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función consulta Entidades: ")
	def consultaEntidades(self, estado):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FIESTADOID, FCNOMBRE FROM CHATBOT.TAMAPESTADOS WHERE UPPER(FCNOMBRE) LIKE UPPER(:estado)")
		result = cursor.execute(None, {'estado': estado})
		result_list = result.fetchall()
		data = {}
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				clave = str(row[0])
				estado = str(row[1])
				data = {"clave": clave, "estado": estado}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función add Imagen: ")
	def addImagen(self, idUsuario, tipoImagen, imagenURL, formato='PNG'):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		response = requests.get(imagenURL)
		img = Image.open(BytesIO(response.content))
		imgByteArr = io.BytesIO()
		img.save(imgByteArr, formato)
		imgByteArr = imgByteArr.getvalue()
		binary_var = cursor.var(cx_Oracle.BLOB)
		binary_var.setvalue(0, imgByteArr) 
		cursor.prepare("INSERT INTO CHATBOT.TAIMAGENES VALUES(:idUser, :tipoImagen, :imagen)")
		cursor.execute(None, {"idUser": idUsuario, "tipoImagen": tipoImagen, "imagen": binary_var})
		connection.commit()
		cursor.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Tiendas: ")
	def consultaTiendas(self, latitud, longitud):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FCNOMBRE, FILATITUD, FILONGITUD, FCTIPO, CHATBOT.UDF_HAVERSINE(FILATITUD, FILONGITUD, :latitud, :longitud) DISTANCIA, INITCAP(FCDIRECCION) FROM CHATBOT.TATIENDAS ORDER BY DISTANCIA FETCH FIRST 10 ROWS ONLY")
		result = cursor.execute(None, {'latitud': latitud, 'longitud': longitud})
		result_list = result.fetchall()
		data = []
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				tienda = str(row[0])
				latitudr = row[1]
				longitudr = row[2]
				tipo = str(row[3])
				distancia = row[4]
				direccion = str(row[5])
				info = {"NameSuc": tienda, "Latitude": latitudr, "Longitude": longitudr, "Channel": tipo, "distance": distancia, "direccion": direccion}
				data.append(info)
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función add Cancelacion: ")
	def addCancelacion(self, idBeneficiario, monto, motivo, lugar=None):
		fecha = self.getFechaHora()
		connection = self.db_pool.acquire()
		cursorinsert = connection.cursor()
		cursorinsert.prepare("INSERT INTO CHATBOT.TACANCELACIONES VALUES(TO_DATE(:fecha,'DD/MM/YYYY HH24:MI:SS'), :idBeneficiario, :monto, :lugar, :motivo)")
		cursorinsert.execute(None, {"fecha": fecha, "idBeneficiario": idBeneficiario, "monto": monto, "lugar": lugar, "motivo": motivo})
		connection.commit()
		cursorinsert.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función obtener Datos Publicos: ")
	def obtenerDatosPublicos(self, idSender, token_page):
		userResponse = requests.get('https://graph.facebook.com/v2.6/' + str(idSender) + '?fields=first_name,last_name,locale,timezone,gender&access_token=' + token_page)
		return json.loads(userResponse.text)

	@cathErrores("Función get Fecha Hora: ")
	def getFechaHora(self):
		fecha = time.strftime("%d/%m/%Y")
		hora = time.strftime("%H:%M:%S")
		return fecha + " " + hora

	@cathErrores("Función get month: ")
	def get_month(self, mes):
		months = {1:'Enero',2:'Febrero',3:'Marzo',4:'Abril',5:'Mayo',6:'Junio',7:'Julio',8:'Agosto',9:'Septiembre',10:'Octubre',11:'Noviembre',12:'Diciembre'}
		return months[mes]

	@cathErrores("Función consulta recordatorio: ")
	def recordatorio(self):
		diasCaduca = 3 #Días en los que caduca el folio a partir de la fecha en que se genera
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT U.FINOIDFACEBOOK, U.FCNOMBRE, T.FIFOLIO, T.FIMONTO, B.FCNOMBRE ||' '|| B.FCAPPATERNO ||' '|| B.FCAPMATERNO, TO_CHAR(T.FDFECHA, 'DD/MM/YYYY'), TO_CHAR(T.FDFECHA + :diasCaduca, 'DD'), TO_CHAR(T.FDFECHA + :diasCaduca, 'MM'), TO_CHAR(T.FDFECHA + :diasCaduca, 'YYYY') FROM CHATBOT.TATRANSACCIONES T INNER JOIN CHATBOT.TABENEFICIARIOS B ON (T.FINOBENEFICIARIO = B.FINOBENEFICIARIO) INNER JOIN CHATBOT.TAUSUARIOS U ON (B.FINOIDFACEBOOK = U.FINOIDFACEBOOK) WHERE T.FICODIGO = 'E' AND ROUND((T.FDFECHA + :diasCaduca) - SYSDATE) <= 1") 
		result = cursor.execute(None, {'diasCaduca': diasCaduca})
		result_list = result.fetchall()
		data = []
		if result.rowcount != 0:
			for row in result_list:  # get data in row
				senderID = row[0]
				userName = str(row[1])
				folio = row[2]
				monto = row[3]
				beneficiaryName = str(row[4])
				fechaCaducidad = str(row[5])
				diaCaduca = row[6]
				print(int(row[7]))
				mesCaduca = self.get_month(int(row[7]))
				anioCaduca = row[8]
				fechaEscrita = str(diaCaduca) + " de " + str(mesCaduca) + " del " + str(anioCaduca)
				info = {'senderID': senderID, 'userName': userName, 'folio': folio, "monto": monto,'beneficiaryName': beneficiaryName, 'fechaCaducidad': fechaCaducidad, 'fechaEscrita': fechaEscrita}
				data.append(info)
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función update notificado: ")
	def updateNotificado(self, folio):
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TATRANSACCIONES SET FICODIGO = 'N' WHERE FIFOLIO = :folio")
		cursorupdate.execute(None, {"folio": folio})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función update Acepta Terminos: ")
	def updateAceptaTerminos(self, idUsuario):
		fecha = self.getFechaHora()
		connection = self.db_pool.acquire()
		cursorupdate = connection.cursor()
		cursorupdate.prepare("UPDATE CHATBOT.TAUSUARIOS SET FIACEPTA = 1, FDACEPTATERMINOS = TO_DATE(:fecha ,'DD/MM/YYYY HH24:MI:SS') WHERE FINOIDFACEBOOK = :idUsuario")
		cursorupdate.execute(None, {"idUsuario": idUsuario, "fecha": fecha})
		connection.commit()
		cursorupdate.close()
		self.db_pool.release(connection)
		return True

	@cathErrores("Función consulta Acepta Terminos: ")
	def consultaAceptaTerminos(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		cursor.prepare("SELECT FIACEPTA FROM CHATBOT.TAUSUARIOS WHERE FINOIDFACEBOOK = :idUsuario")
		result = cursor.execute(None, {'idUsuario': idUsuario})
		result_list = result.fetchall()
		data = {}
		for row in result_list:  # get data in row
			acepta = row[0]
			data = {"tyc": acepta}
		cursor.close()
		self.db_pool.release(connection)
		return json.loads(json.dumps(data))

	@cathErrores("Función update telefono: ")
	def updateTelefono(self, idUsuario,telefono, confirmacion):
		connection = self.db_pool.acquire()

		cursor = connection.cursor()
		PATIPOOPERACION="AGREGA O MODIFICA TELEFONO"
		PAUSUARIOID=idUsuario
		PACLIENTEIDDEX = cursor.var(cx_Oracle.NUMBER)
		PANOMBRE = cursor.var(cx_Oracle.STRING)
		PAAPATERNO = cursor.var(cx_Oracle.STRING)
		PAAMATERNO = cursor.var(cx_Oracle.STRING)
		PAFECHANACIMIENTO = cursor.var(cx_Oracle.STRING)
		PATELEFONO=telefono
		PALISTANEGRA = cursor.var(cx_Oracle.NUMBER)
		PAIMAGEN = cursor.var(cx_Oracle.BLOB)
		PACONFIRMACIONTEL = confirmacion
		PACODIGO = cursor.var(cx_Oracle.NUMBER)
		PAMENSAJE = cursor.var(cx_Oracle.STRING)
		PADATOSUSUARIO = cursor.var(cx_Oracle.CURSOR)
		args = (PATIPOOPERACION, PAUSUARIOID, PACLIENTEIDDEX, PANOMBRE, PAAPATERNO, PAAMATERNO, PAFECHANACIMIENTO,PATELEFONO, PALISTANEGRA, PAIMAGEN, PACONFIRMACIONTEL, PADATOSUSUARIO, PACODIGO, PAMENSAJE)
		try:
			cursor.callproc("CHATBOT.PASRVUSUARIOS.SPGESTIONUSUARIOS", args)
			data = {}
			codigo = PACODIGO.getvalue()
			data["codigo"]=codigo
			mensaje = PAMENSAJE.getvalue()
			data["mensaje"]=mensaje
		except Exception as e:
			tag = "updateTelefono"
			message = str(e)
			fecha = time.strftime("%d-%m-%Y")
			hora = time.strftime("%H:%M:%S")
			clob1 = "~| ERROR |" + fecha + " " + hora + " | " + tag + " | " + message + "|"
			self.ejecutaBitacora(1, tag, message, clob1)

		cursor.close()
		self.db_pool.release(connection)

		return json.loads(json.dumps(data))

	@cathErrores("Función consulta status telefono: ")
	def consultaStatusTelefono(self, idUsuario):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		PATIPOOPERACION = "VALIDA TELEFONO CLIENTE"
		PAUSUARIOID = idUsuario
		PANOMBRE = cursor.var(cx_Oracle.STRING)
		PAAPATERNO = cursor.var(cx_Oracle.STRING)
		PACONFIRMACIONTEL = cursor.var(cx_Oracle.NUMBER)
		PACODIGO = cursor.var(cx_Oracle.NUMBER)
		PAMENSAJE = cursor.var(cx_Oracle.STRING)
		PADATOSUSUARIO = cursor.var(cx_Oracle.CURSOR)
		args = (PATIPOOPERACION, PAUSUARIOID, PANOMBRE, PAAPATERNO, PACONFIRMACIONTEL, PADATOSUSUARIO, PACODIGO, PAMENSAJE)
		try:
			cursor.callproc("CHATBOT.PASRVUSUARIOS.SPVALIDADUSUARIOS", args)
			data = {}
			codigo = PACODIGO.getvalue()
			data["codigo"] = codigo
			mensaje = PAMENSAJE.getvalue()
			data["mensaje"] = mensaje
		except Exception as e:
			tag = "consultaStatusTelefono"
			message = str(e)
			fecha = time.strftime("%d-%m-%Y")
			hora = time.strftime("%H:%M:%S")
			clob1 = "~| ERROR |" + fecha + " " + hora + " | " + tag + " | " + message + "|"
			self.ejecutaBitacora(1, tag, message, clob1)


		cursor.close()
		self.db_pool.release(connection)
		return (int(codigo))

	@cathErrores("Función que guarda logs en bd: ")
	def ejecutaBitacora(self, mod, tag, message, fin):
		connection = self.db_pool.acquire()
		cursor = connection.cursor()
		clase = cursor.var(cx_Oracle.STRING)
		clase.setvalue(0, str(tag))
		model = cursor.var(cx_Oracle.NUMBER)
		model.setvalue(0, int(mod))
		clob1 = cursor.var(cx_Oracle.CLOB)
		clob1.setvalue(0, fin)
		cursor.callproc("PASRVBITACORASBOTLOG.SPALTABITACORALOGS", (model, clase, message, clob1))
		print("Log guardado en bd")
		cursor.close()
		self.db_pool.release(connection)
		return 0
