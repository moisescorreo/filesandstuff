def find(num_state):
	try:
		errors_estado_default = {1:"Ocurrió un error inesperado en nuestro sistema"}
		errors_estado_10 = {1:"Intenta con un hola"}
		errors_estado_20 = {1:"Presiona una opción del recuadro anterior"}
		errors_estado_31 = {1:"Presiona una opción del recuadro anterior :/"}
		errors_estado_33 = {1:[7]}
		errors_estado_34 = {1:["Por favor seleccione una de las opciones anteriores o escriba su motivo ;)",33], 2:"Ocurrió un error inesperado en nuestro sistema"}
		errors_estado_41 = {1:"Sólo puedes regresar al menú principal"}
		errors_estado_61 = {1:"Ingresa un nombre por favor", 2:"Ingresa un nombre completo por favor",3:"Ocurrió un error por favor ingresa el nombre nuevamente :,("}
		errors_estado_62 = {1:[7]}
		errors_estado_64 = {1:"Ingresa un nombre por favor", 2:"Ocurrió un error por favor ingresa el nombre nuevamente :,("}
		errors_estado_65 = {1:"Ingresa un apellido por favor", 2:"Ocurrió un error por favor ingresa el apellido nuevamente"}
		errors_estado_66 = {1:"Ingresa un apellido por favor", 2:"Ocurrió un error por favor ingresa el apellido nuevamente"}
		errors_estado_69 = {1:"Responde Si o No por favor"}
		errors_estado_71 = {1:"Presiona una opción del recuadro anterior"}
		errors_estado_81 = {1:"Presiona una opción del recuadro anterior", 2:"Ocurrió un error, vuelve a elegir el beneficiario",3:"Ocurrió un error, no se pudo eliminar beneficiario",4:"Ocurrió un error, no se pudo editar beneficiario",5:"Ocurrió un error, no se pudo editar beneficiario"}
		errors_estado_89 = {1:"Escribe un estado"}
		errors_estado_86 = {1:["Selecciona un estado",85]}
		errors_estado_87 = {1:["Selecciona un estado",85]}
		errors_estado_88 = {1:[7]}
		errors_estado_100 = {1:"Ingresa una cantidad por favor",2:"Introduce la cantidad a enviar, puede ser desde $20 hasta $1,000 pesos"}
		errors_estado_111 = {1:"Ingresa un nombre por favor", 2:"Ingresa tu nombre completo por favor",3:"Ocurrió un error por favor ingresa el nombre nuevamente"}
		errors_estado_112 = {1:[7]}
		errors_estado_114 = {1:"Ingresa un nombre por favor", 2:"Ocurrió un error por favor ingresa el nombre nuevamente"}
		errors_estado_115 = {1:"Ingresa un apellido por favor",2:"Ocurrió un error por favor ingresa el apellido nuevamente"}
		errors_estado_116 = {1:"Ingresa un apellido por favor",2:"Ocurrió un error por favor ingresa el apellido nuevamente"}
		errors_estado_121 = {1:"Ingresa una fecha por favor",2:"El formato válido es dd/Mes/aaaa"}
		errors_estado_122 = {1:[7]}
		errors_estado_125 = {1:["Ocurrió un problema, intenta más tarde",5]}
		errors_estado_127 = {1:["Ocurrió un problema, intenta más tarde",5]}
		errors_estado_129 = {1:["Ocurrió un problema, intenta más tarde",5]}
		errors_estado_132 = {1:[7]}
		errors_estado_134 = {1:"Ingresa calle y número",2:"Ingresa sólo calle y número",3:"Ocurrió un error ingresa nuevamente calle y número"}
		errors_estado_135 = {1:"Ingresa una colonia por favor",2:"Ocurrió un error ingresa nuevamente colonia por favor"}
		errors_estado_136 = {1:"Ingresa código postal por favor",2:"No encontramos el código postal. ¿Nos lo puedes confirmar nuevamente por favor?",3:"Ingresa un código postal válido por favor"}
		errors_estado_151 = {1:[227]}
		errors_estado_180 = {1:"Enviame tu ubicación por favor",2:"Ocurrió un problema al mostrate los puntos mas cercanos, intenta más tarde. :/"}
		errors_estado_200 = {1:["Selecciona uno de los dos botones",210]}
		errors_estado_250 = {1:"Ingresa tu ubicación por favor",2:["Ocurrió un error, intenta más tarde",250]}
		errors_estado_5 = {1:"Lo sentimos, no se pudo cancelar tu operación intenta más tarde"}
		errors_estado_4 = {1:"Lo sentimos, no se pudo cancelar tu operación intenta más tarde"}
		errors_estado_7 = {1:[7]}
		errors_estado_140 = {1:["Los datos que proporcionaste son incorrectos. Intenta otra vez",5],2:"Error al agregar beneficiario",3:"Ocurrió un problema intenta más tárde. :D",4:["No es posible brindarle el servicio en este momento, por favor comunícate al Call Center de Transferencia: 01-800-050-4104",5],5:["Para seguir operando es necesario que contestes un breve cuestionario, por favor acude a una sucursal a completar tu envío.",5]}
		errors_estado_150 = {1:"Ocurrió un problema intenta más tárde. :D"}
		errors_estado_152 = {1:["Ocurrió un error, intenta más tarde",5], 2:["Ocurrió un error, intenta más tarde",160], 3:["Llegaste al máximo de operaciónes permitidas :/",5]}
		errors_estado_170 = {1:["Ocurrió un error, intenta más tarde",151]}
		errors_estado_154 = {1:["Por favor seleccione una de las opciones anteriores o escriba su motivo ;)",153]}
		errors_estado_225 = {1:"Ingresa una cantidad por favor",2:"Introduce la cantidad a enviar, puede ser desde $20 hasta $1000 pesos",3:["Error en la cotización por favor intenta mas tarde :/",5]}
		errors_estado_155 = {1:"Por favor escriba un motivo :)"}
		errors_estado_226 = {1:["Ocurrió un error inesperado en nuestro sistema",5],2:[7],4:["No es posible brindarle el servicio en este momento, por favor comunícate al Call Center de Transferencia: 01-800-050-4104",5],5:["Para seguir operando es necesario que contestes un breve cuestionario, por favor acude a una sucursal a completar tu envío.",5]}
		errors_estado_137 = {1:"Ingresa código postal por favor",3:"Ingresa un código postal válido por favor"}
		errors_estado_231 = {1:[232]}
		states = {
			10:{'state':10, 'type':'L', 'type_input':['postback','message','quick_replies'], 'filters_availables': ['greetings'], 'errors':errors_estado_10},
			20:{'state':20, 'type':'L', 'type_input':['postback','message'], 'filters_availables': [], 'errors':errors_estado_20},
			31:{'state':31, 'type':'L', 'type_input':['postback'], 'filters_availables': [], 'errors':errors_estado_31},
			33:{'state':33, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_33},
			34:{'state':34, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_34},
			41:{'state':41, 'type':'L', 'type_input':['quick_replies'], 'filters_availables': [], 'errors':errors_estado_41},
			61:{'state':61, 'type':'L', 'type_input':['message'], 'filters_availables': ['names'], 'errors':errors_estado_61},
			62:{'state':62, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_62},
			64:{'state':64, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_64},
			65:{'state':65, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_65},
			66:{'state':66, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_66},
			69:{'state':69, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_69},
			71:{'state':71, 'type':'L', 'type_input':['postback'], 'filters_availables': [], 'errors':errors_estado_71},
			81:{'state':81, 'type':'L', 'type_input':['postback'], 'filters_availables': [], 'errors':errors_estado_81},
			89:{'state':89, 'type':'L', 'type_input':['message'], 'filters_availables': ['state'], 'errors':errors_estado_89},
			86:{'state':86, 'type':'L', 'type_input':['quick_replies'], 'filters_availables': [], 'errors':errors_estado_86},
			87:{'state':87, 'type':'L', 'type_input':['quick_replies'], 'filters_availables': [], 'errors':errors_estado_87},
			88:{'state':88, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_88},
			100:{'state':100, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_100},
			111:{'state':111, 'type':'L', 'type_input':['message'], 'filters_availables': ['names'], 'errors':errors_estado_111},
			112:{'state':112, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_112},
			114:{'state':114, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_114},
			115:{'state':115, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_115},
			116:{'state':116, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_116},
			121:{'state':121, 'type':'L', 'type_input':['message'], 'filters_availables': ['date'], 'errors':errors_estado_121},
			122:{'state':122, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_122},
			125:{'state':125, 'type':'L', 'type_input': ['message', 'quick_replies'], 'filters_availables': [],'errors': errors_estado_125},
			127:{'state':127, 'type': 'L', 'type_input': ['message'], 'filters_availables': [], 'errors': errors_estado_127},
			129:{'state':129, 'type': 'L', 'type_input': ['message'], 'filters_availables': [], 'errors': errors_estado_129},
			132:{'state':132, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_132},
			134:{'state':134, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_134},
			135:{'state':135, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_135},
			136:{'state':136, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_136},
			137:{'state':137, 'type':'L', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_137},
			151:{'state':151, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_151},
			180:{'state':180, 'type':'L', 'type_input':['location','quick_replies'], 'filters_availables': [], 'errors':errors_estado_180},
			200:{'state':200, 'type':'L', 'type_input':['location','quick_replies'], 'filters_availables': [], 'errors':errors_estado_200},
			225:{'state':225, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_225},
			226:{'state':226, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_226},
			231:{'state':231, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables': [], 'errors':errors_estado_231},
            154:{'state':154, 'type':'L', 'type_input':['message','quick_replies'], 'filters_availables':[], 'errors':errors_estado_154},
			153:{'state':153, 'type':'E', 'type_input':[], 'filters_availables':[], 'errors':errors_estado_default},
			4:{'state':4, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_4},
			5:{'state':5, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_5},
			6:{'state':6, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			7:{'state':7, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			30:{'state':30, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			32:{'state':32, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			40:{'state':40, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			42:{'state':42, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			50:{'state':50, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			60:{'state':60, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			63:{'state':63, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			68:{'state':68, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			70:{'state':70, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			80:{'state':80, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			82:{'state':82, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			91:{'state':91, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			85:{'state':85, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			90:{'state':90, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			110:{'state':110, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			113:{'state':113, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			120:{'state':120, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			124:{'state':124, 'type': 'E', 'type_input': [], 'filters_availables': [],'errors': errors_estado_default},
			126:{'state':126, 'type': 'E', 'type_input': [], 'filters_availables': [],'errors': errors_estado_default},
			128:{'state':128, 'type': 'E', 'type_input': [], 'filters_availables': [],'errors': errors_estado_default},
			130:{'state':130, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			133:{'state':133, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			160:{'state':160, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			250:{'state':250, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_250},
			210:{'state':210, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			123:{'state':123, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			140:{'state':140, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_140},
			150:{'state':150, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_150},
			152:{'state':152, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_152},
			170:{'state':170, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_170},
			155:{'state':155, 'type':'E', 'type_input':['message'], 'filters_availables': [], 'errors':errors_estado_155},
			220:{'state':220, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			227:{'state':227, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
            230:{'state':230, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
            233:{'state':233, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			234:{'state':234, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			235:{'state':235, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			236:{'state':236, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default},
			251:{'state':251, 'type':'E', 'type_input':[], 'filters_availables': [], 'errors':errors_estado_default}
			}
		return states[num_state]
	except:
		states = {10:{'state':10, 'type':'L', 'type_input':['postback','message','quick_replies'], 'filters_availables': ['greetings'], 'errors':errors_estado_10}}
