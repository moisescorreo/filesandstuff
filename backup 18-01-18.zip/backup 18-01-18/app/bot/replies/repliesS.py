from salinasApi import peticiones
import  modules.ticket as ticket
import time, os
import logging
import json
from io import StringIO
from crash_report import send_sms
import modules.logger_register as logger



class Replies_S(object):
    """Clase de estados de servicios"""
    def __init__(self, user, ora, replies_bot):
        self.user = user
        self.ora = ora
        self.replies_bot = replies_bot

    def error_deco(func): 
        """decorator function"""
        def handle_error(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error = 'Failed function because of {:}'.format(e)
                logger.write_error("repliesS", error)
                return ['error',1]
        return handle_error

    #VERIFICAR usuario en base de datos como cliente
     
    def verifica_usuario_cliente(self):
        data = self.ora.consultaDatosUsuario(self.user.sender_id)
        data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
        #response = peticiones.busquedaPorNombreP(data_beneficiary['uid'],data['nombre'],data['apPaterno'],data['apMaterno'], data['fechaNac'])
        response = [0,"OPERACION EXITOSA"] 
        if response[1] == "OPERACION EXITOSA":
            return ['find',133] #133
        else:
            self.replies_bot.send_alert(self.user.sender_id,"Aún no eres cliente de Banco Azteca")
            return ['find',10]

    #VALIDAR datos del usuario y beneficiario así como la lista negra
    # 
    def valida_usuario_beneficiario_listanegra(self):
        print ("estoy en valida beneficiario lista negra")
        data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
        data_user = self.ora.consultaDatosUsuario(self.user.sender_id)
        zip_code = self.ora.consultaCodigoPostal(data_user['cp'])
        if not zip_code.get('cp'):
            zip_code = {'municipio': 'NADA', 'cp': '14728', 'estado': 'NADA'}
            zip_code = json.loads(json.dumps(zip_code))
        print(str(self.user.sender_id)+" ---------------------------------ZIPCODE-----------------------------\n"+str(zip_code))
        if self.user.firs_time == True and zip_code!=False:
            user_id = peticiones.ClientAltaRemitenteP(data_beneficiary['uid'],data_user['nombre'],data_user['apPaterno'],data_user['apMaterno'],data_user['fechaNac'],data_user['colonia'],zip_code['estado'],zip_code['municipio'],data_beneficiary['calle_num'],zip_code['cp'])
            if user_id[0]==True and user_id[1].find("EXITOS")>0:
                self.ora.updateIdClienteUsuario(self.user.sender_id, user_id[2])
                beneficiary_id = peticiones.ClientAltaBeneficiarioP(data_beneficiary['uid'], data_beneficiary['nombre'], data_beneficiary['apPaterno'], data_beneficiary['apMaterno'],user_id[2])
                if beneficiary_id[0]==True and beneficiary_id[1].find("EXITO")>0:
                    self.ora.updateExtra(self.user.sender_id, 'beneficiary_id', beneficiary_id[2])
                    if self.ora.addBeneficiario(self.user.sender_id, beneficiary_id[2], data_beneficiary['nombre'], data_beneficiary['apPaterno'], data_beneficiary['apMaterno']): 
                        pass
                    else:
                     	logger.error("Error al agregar beneficiario")
                     	return ['error',2]
                else:
                    return ['error',1]

            else:
            	return ['error',1]       
        else:
            if data_beneficiary['beneficiary_id'] == '0':
                user_id = self.ora.consultaDatosUsuario(self.user.sender_id)
                beneficiary_id = peticiones.ClientAltaBeneficiarioP(data_beneficiary['uid'], data_beneficiary['nombre'], data_beneficiary['apPaterno'], data_beneficiary['apMaterno'], user_id['idCliente'])
                if self.ora.updateExtra(self.user.sender_id, 'beneficiary_id', beneficiary_id[2]) == False: print(str(self.user.sender_id)+": ERROR UPDATE EXTRA")
                if self.ora.addBeneficiario(self.user.sender_id, beneficiary_id[2], data_beneficiary['nombre'], data_beneficiary['apPaterno'], data_beneficiary['apMaterno']) == False: print(str(self.user.sender_id)+": ERROR ADD BENEFICIARIO")
        listaNegra = peticiones.ClientValidaP(data_beneficiary['uid'],data_user['nombre'],data_user['apPaterno'],data_user['apMaterno'],data_user['fechaNac']) 
        self.ora.updateListaNegra(self.user.sender_id,listaNegra[2])
        if listaNegra[0]==True and listaNegra[1].find("EXITOSA")>0:
            if listaNegra[2]==0 or listaNegra[2]==2:
                return ['find',150]

            elif listaNegra[2]==1 or listaNegra[2] == 3:
                return ['error',4]

            elif listaNegra[2]==4 or listaNegra[2]==5:
                return ['error',5]

            else:
                return ['find',160]
        else:
            return ['find',160]

    #COTIZAR y MOSTRAR si quiere confirmar transacción
     
    def cotiza(self):
        data_user = self.ora.consultaDatosUsuario(self.user.sender_id)
        data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
        data_extra = self.ora.consultaExtras(self.user.sender_id)
        print(str(self.user.sender_id)+": DATA BENEFICIARY----------------------------------------------\n"+str(data_beneficiary))
        quantity = data_beneficiary['quantity']
        quantityF = peticiones.EnvioCotizaP(data_extra['uid'],data_user['idCliente'],quantity)
        status=self.ora.consultaStatusTelefono(self.user.sender_id)

        if quantityF[0]==True and quantityF[2].find("EXITOSA")>0:
            if status==1 or status==2 or self.user.firs_time==True or status==3:
                if status==3:
                    telephone = ''
                    confirmacion = 0
                    self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
                self.replies_bot.state_150(self.user.sender_id, data_user['nombre'], data_beneficiary['nombre'],data_beneficiary['apPaterno'], data_beneficiary['apMaterno'], quantity,quantityF[1])
                return ['save', 151, 'L']
            elif status==0:
                return ['find', 124]
        else:
            print("antes del else cotiza")
            print(str(self.user.sender_id)+": Error en la cotización previa")
            return ['error',1]

    #GENERAR Folio
     
    def genera_folio(self):

        data_user = self.ora.consultaDatosUsuario(self.user.sender_id)
        data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
        pre_folio = peticiones.EnvioGeneraP(data_beneficiary['uid'],int(data_user['idCliente']),int(data_beneficiary['beneficiary_id']), data_beneficiary['quantity'])
        #zip_code = consultaCodigoPostal(str(data_user['cp']))
        estado_user = str(data_user['estado'])
        print(estado_user.upper())
        if estado_user.upper() == "NONE":
            print("1")
            estado_user = 'AGUASCALIENTES'
            municipio = 'AGUASCALIENTES'
        else:
            print("2")
            estado_user = data_user['estado']
            municipio = data_user['municipio']
            #self.replies_bot.state_135(self.user.sender_id)
            #return['save',136.'L']
        #else:
        id_estado = self.ora.consultaEntidades(estado_user)
        print(id_estado['clave'])
        print("3")

        if not id_estado.get('clave'):
            print("4")
            id_estado = {'estado': 'AGUASCALIENTES', 'clave': '1'}
            id_estado = json.loads(json.dumps(id_estado))

        if len(pre_folio) > 3:
            print("5")
            pld = peticiones.EnvioPldP(data_beneficiary['uid'],pre_folio[1],data_user['idCliente'],data_user['direccion'],data_user['colonia'],data_user['cp'],estado_user,municipio,data_user['fechaNac'])
            print("||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
            print(pld)
            print("||||||||||||||||||||||||||||||||||||||||||||||||||||||||")

            self.ora.addExtra(self.user.sender_id,'civa', (int(pre_folio[9]) - int(data_beneficiary['quantity'])))
            self.ora.addExtra(self.user.sender_id,'quantityT',pre_folio[9])
            if pre_folio[0] == True and pre_folio[13].find('EXITOSA')>0 and pre_folio[12] == "E":
                self.ora.addExtra(self.user.sender_id, 'folio', pre_folio[1])
                self.ora.addEnvio(data_beneficiary['uid'],pre_folio[1],pre_folio[2],pre_folio[3],pre_folio[4],pre_folio[5],pre_folio[6],pre_folio[7],pre_folio[8],pre_folio[9],pre_folio[10],pre_folio[11],data_beneficiary['beneficiary_id'],pre_folio[12],pre_folio[13])
                return ['find',170]
            else:
                return ['error',2]
        elif pre_folio[1] =='2':
            return ['error',3]
        else:
            return ['error',2]

    # Notificacion activacion de codigo
    # 
    def notificacion_activacion_codigo(self):
        data_user = self.ora.consultaDatosUsuario(self.user.sender_id)
        data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
        state = self.ora.consultaUnBeneficiario(self.user.sender_id,data_beneficiary['beneficiary_id'])
        name_ticket = data_user['idCliente']
        date = time.strftime("%d/%m/%y")
        quantityMasExtra = (int(data_beneficiary['quantityT'])+7)
        lista_datos = {'date':date, 'quantity':str(data_beneficiary['quantity']), 'civa':str(data_beneficiary['civa']),'quantityT':str(quantityMasExtra), 'beneficiary':str(data_beneficiary['nombre']), 'folio':str(data_beneficiary['folio'])}
        ticket.save_reference_ticket(lista_datos, str(name_ticket))
        image_url = os.environ['URL_IMG']+"img/"+str(name_ticket)+".png"
        print(str(self.user.sender_id)+": "+image_url)
        self.replies_bot.state_170(self.user.sender_id, self.user.name, image_url,data_beneficiary['quantityT'],str(data_beneficiary['folio']))
        return ['save',180,'L']
