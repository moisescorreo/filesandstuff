from filters import FilterQuantity
from salinasApi import peticiones
import logging
from io import StringIO
from crash_report import send_sms
from storageConversation import storageConversationModule
import modules.logger_register as logger
from nltk.util import ngrams
import re


class Replies_L(object):
    """Clase de estados de lectura"""
    def __init__(self, user, ora, replies_bot):
        self.user = user
        self.ora = ora
        self.replies_bot = replies_bot

    def error_deco(func): 
        """decorator function"""
        def handle_error(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error = 'Failed function because of {:}'.format(e)
                logger.write_error("repliesL", error)
                return ['error',1]
        return handle_error
        
    #LEE Saludo
     
    def saludo(self, payload):
        self.ora.eliminaExtras(self.user.sender_id)
        if payload[0] == 'message' or payload[0] == 'quick_replies' :
            if payload[1]  == 1:
                self.replies_bot.state_10(self.user.sender_id, self.user.name)
                return['save',20,'L']
            #elif payload[1] == 0:
                #self.replies_bot.send_alert(self.user.sender_id, "Mariachi IO :) ")
            else:
                return['error',1]
        elif payload[0] == 'postback' and payload[1] == 'INIT_USERBOT':
            self.replies_bot.state_10(self.user.sender_id, self.user.name)
            return['save',20,'L']
        else:
            return['error',1]

    #LEE Botones saludo
     
    def botones_saludo(self, payload):
        if payload[0] == 'postback':
            if payload[1] == '30':
                return['find',30]
            elif payload[1] == '32':
                return['find',32]
            elif payload[1] == '50':
                uid = self.ora.generaUid()
                print(str(self.user.sender_id)+" UID: "+str(uid))
                self.ora.addExtra(self.user.sender_id,'uid',uid['uid'])
                return['find',50]
            elif payload[1] == '210':
                return['find',210]
            elif payload[1] == '220':
                return['find',220]
            else:
                return['error' ,1]
        elif payload[0] == 'message':
            if payload[1].upper().replace(' ','') == "ENVIARDINERO":
                return['find',50]
            elif payload[1].upper().replace(' ','') == "NO":
                return['find',250]
            else:
                return['error',1]
        else:
            return['error',1]

    #LEER las opciones de ayuda
     
    def botones_ayuda(self, payload):
        if payload[1] == '6':
            return['find',6]
        elif payload[1] == '40':
            return['find',40]
        else:
            return['error',1]

    #LEER regreso al menu principal
     
    def quick_menuprincipal(self, payload):
        if payload[1] == "MENU":
            return['find',5]
        else:
            return['error',1]

    #LEER nombre completo del beneficiario
     
    def nombre_completo_beneficiario(self, payload):
        if payload[1] == False:
            return['error',2]
        else:
            extra = self.ora.consultaExtras(self.user.sender_id)
            if extra.get('nombre') and extra.get('apPaterno') and extra.get('apMaterno') and extra.get('beneficiary_id'):
                if self.ora.updateExtra(self.user.sender_id, 'beneficiary_id', '0') and self.ora.updateExtra(self.user.sender_id, 'nombre', payload[1][0]) and self.ora.updateExtra(self.user.sender_id, 'apPaterno', payload[1][1]) and self.ora.updateExtra(self.user.sender_id, 'apMaterno', payload[1][2]):
                    print("MODIFIQUE LOS NOMBRES DE LOS BENEFICIARIOS EN NUEVO BENEFICIARIO")
                    self.replies_bot.state_verify(self.user.sender_id, payload[1])
                    return['save',62,'L']
                else:
                    return['error',3]
            else:
                if self.ora.addExtra(self.user.sender_id, 'nombre', payload[1][0]) and self.ora.addExtra(self.user.sender_id, 'apPaterno', payload[1][1]) and self.ora.addExtra(self.user.sender_id, 'apMaterno', payload[1][2]):
                    self.replies_bot.state_verify(self.user.sender_id, payload[1])
                    return['save',62,'L']
                else:
                    return['error',3]

    #LEER CONFIRMACIÓN NOMBRE
     
    def confirmar_nombre_beneficiario(self, payload):
        if payload[1].upper() == 'SI':
            self.ora.addExtra(self.user.sender_id, 'beneficiary_id', '0')
            extra = self.ora.consultaExtras(self.user.sender_id)
            if extra.get('quantity'):
                return['find',110]
            else:
                return['find',90]
        elif payload[1].upper() == 'NO':
            return['find',63]
        else:
            return['error',1]

    #LEER nuevo nombre y MOSTRAR corrige apellido paterno
     
    def nombre_beneficiario(self, payload):
        if self.ora.updateExtra(self.user.sender_id, "nombre", payload[1]):
            self.replies_bot.state_64(self.user.sender_id)
            return['save',65,'L']
        else:
            return['error',2]

    #LEER nuevo apellido y MOSTRAR corrige apellido materno
     
    def apellido_beneficiario(self, payload):
        if self.ora.updateExtra(self.user.sender_id, "apPaterno", payload[1]):
            self.replies_bot.state_65(self.user.sender_id)
            return['save',66,'L']
        else:
            return['error',2]

    #LEER nuevo apellido materno
     
    def materno_beneficiario(self, payload):
        name = self.ora.consultaExtras(self.user.sender_id)
        if self.ora.updateExtra(self.user.sender_id, "apMaterno", payload[1]):
            names = [name['nombre'], name['apPaterno'], payload[1]]
            self.replies_bot.state_verify(self.user.sender_id, names)
            return['save',62,'L']
        else:
            return['error',2]

    #LEER botones opción
     
    def botones_seleccionar_beneficiario(self, payload):
        if payload[1] == '80':
            return ['find',80]
        elif payload[1] == '60':
            return ['find',60]

    #LEER seleccionar o borrar contacto
     
    def carrusel_contactos(self, payload):
        postback = payload[1]
        if postback[0] == "S":
            beneficiary = self.ora.consultaUnBeneficiario(self.user.sender_id, postback[1:])
            extra = self.ora.consultaExtras(self.user.sender_id)

            if extra.get('nombre') and extra.get('apPaterno') and extra.get('apMaterno') and extra.get('beneficiary_id'):
                if self.ora.updateExtra(self.user.sender_id, 'beneficiary_id', postback[1:]) and  self.ora.updateExtra(self.user.sender_id, 'nombre', beneficiary['nombre']) and self.ora.updateExtra(self.user.sender_id, 'apPaterno', beneficiary['apPaterno']) and self.ora.updateExtra(self.user.sender_id, 'apMaterno', beneficiary['apMaterno']):
                    print("MODIFIQUE LOS NOMBRES DE LOS BENEFICIARIOS")
                    if extra.get('quantity'):
                        return ['find',150]
                    else:
                        return ['find',90]
                else:
                    return['error',2]
                    return ['find',80]
            else:
                if self.ora.addExtra(self.user.sender_id, 'beneficiary_id', postback[1:]) and  self.ora.addExtra(self.user.sender_id, 'nombre', beneficiary['nombre']) and self.ora.addExtra(self.user.sender_id, 'apPaterno', beneficiary['apPaterno']) and self.ora.addExtra(self.user.sender_id, 'apMaterno', beneficiary['apMaterno']):
                    extra = self.ora.consultaExtras(self.user.sender_id)
                    if extra.get('quantity'):
                        return ['find',150]
                    else:
                        return ['find',90]
                else:
                    return['error',2]
                    return ['find',80]
        elif postback[0] == "B":
            if self.ora.eliminaBeneficiario(self.user.sender_id, postback[1:]):
                self.replies_bot.send_alert(self.user.sender_id, "Contacto eliminado")
                return ['find',80]
            else:
                return['error',3]
        else:
            return['error',1]

    #PREGUNTA la region federativa del beneficario
     
    def region_federativa(self,payload):
        state = payload[1]
        state_fed = self.ora.consultaEstado(self.user.sender_id)
        if state_fed['estAnterior'] == 82:
            if state==None:
                self.ora.addExtra(self.user.sender_id, 'new_state1',"n")
                return ['find',85]
            else:
                if state =="Mexico":
                    state = "México"
                elif state =="Ciudad De Mexico":
                    state = "Ciudad De México"
                elif state == "Michoacan":
                    state = "Michoacán"
                elif state == "Nuevo Leon":
                    state = "Nuevo León"
                elif state == "Queretaro":
                    state = "Querétaro"
                elif state == "San Luis Potosi":
                    state ="San Luis Potosí"
                elif state == "Yucatan":
                    state = "Yucatán"
                self.ora.addExtra(self.user.sender_id, 'new_state',state)
                self.replies_bot.state_verify_states(self.user.sender_id, state)
                return ['save', 88, 'L']
        else:
            if state==None:
                return ['find',85]
            else:
                if state =="Mexico":
                    state = "México"
                elif state =="Ciudad De Mexico":
                    state = "Ciudad De México"
                elif state == "Michoacan":
                    state = "Michoacán"
                elif state == "Nuevo Leon":
                    state = "Nuevo León"
                elif state == "Queretaro":
                    state = "Querétaro"
                elif state == "San Luis Potosi":
                    state ="San Luis Potosí"
                elif state == "Yucatan":
                    state = "Yucatán"
                self.replies_bot.state_verify_states(self.user.sender_id, state)
                self.ora.addExtra(self.user.sender_id,'places',state)
                return ['save', 88, 'L']

    #SELECCIONA el estado de acuerdo a la región
     
    def selecciona_region(self,payload):
        state = payload[1]
        print("EStado")
        print(state)
        if state == "1":
            self.replies_bot.state_area_1(self.user.sender_id)
            return ['save', 87, 'L']
        elif state == "2":
            self.replies_bot.state_area_2(self.user.sender_id)
            return ['save', 87, 'L']
        elif state == "3":
            self.replies_bot.state_area_3(self.user.sender_id)
            return ['save', 87, 'L']
        elif state == "4":
            self.replies_bot.state_area_4(self.user.sender_id)
            return ['save', 87, 'L']
        else:
            self.replies_bot.send_alert(self.user.sender_id, "Selecciona un estado")
            return['error',1]

    #LEER estados
     
    def selecciona_estado(self,payload):
        state = payload[1]   
        if state == "back":
            return ['find',85]
        else:
            data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
            if data_beneficiary.get('new_state1'):
                self.replies_bot.state_verify_states(self.user.sender_id, state)
                self.ora.addExtra(self.user.sender_id, 'new_state',state)
                self.ora.addExtra(self.user.sender_id,'places',state)
                return ['save', 88, 'L']
            else:
                self.replies_bot.state_verify_states(self.user.sender_id, state)
                self.ora.addExtra(self.user.sender_id,'places',state)
                return ['save', 88, 'L']

    #LEER confirmar estado
     
    def confirmar_estado(self,payload):
        if payload[1].upper() == 'SI':
            data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
            if data_beneficiary.get('new_state'):
                self.ora.updateEntidadBeneficiario(self.user.sender_id,data_beneficiary['beneficiary_id'],data_beneficiary['new_state'])
                return ['find',80]
            else:
                return ['find',90]
        elif payload[1].upper() == 'NO':
            return ['find',85]
        else:
            return ['error',1]

    #LEER monto a enviar
     
    def monto(self, payload):
        if payload[1].upper() == 'OTRA CANTIDAD':
            quantity = "0"
        else:
            quantity = payload[1]
        response = FilterQuantity.validate(quantity)
        if response[0]:
            consultaExtras = self.ora.consultaExtras(self.user.sender_id)
            quantity = response[1]
            if consultaExtras.get('quantity'):
                self.ora.updateExtra(self.user.sender_id,"quantity",str(quantity))
                return ['find',110]
            else:
                self.ora.addExtra(self.user.sender_id, "quantity", str(quantity))
                return ['find',110]
        else:
            return ['error',2]

    #LEER nombre completo remitente
     
    def nombre_completo_remitente(self, payload):
        names = payload[1]
        if names == False:
            return ['error',2]
        else:
            if self.ora.updateNombreUsuario(self.user.sender_id, names[0], names[1], names[2]):
                self.replies_bot.state_verify(self.user.sender_id, names)
                return ['save',112,'L']
            else:
                return ['error',3]

    #LEER CONFIRMACIÓN NOMBRE
     
    def confirmar_nombre_remitente(self, payload):
        if payload[1].upper() == 'SI':
            return ['find',120]
        elif payload[1].upper() == 'NO':
            return ['find',113]
        else:
            return ['error',1]

    #LEER nuevo nombre y MOSTRAR corrige apellido paterno
     
    def nombre_remitente(self, payload):
        name = payload[1]
        if self.ora.updateNombreUsuario(self.user.sender_id, name):
            self.replies_bot.state_114(self.user.sender_id)
            return ['save',115,'L']
        else:
            return ['error',2]

    #LEER nuevo apellido y MOSTRAR corrige apellido materno
     
    def apellido_remitente(self, payload):
        last_name = payload[1]
        names = self.ora.validaUsuario(self.user.sender_id)
        if self.ora.updateNombreUsuario(self.user.sender_id, names['nombre'], last_name):
            self.replies_bot.state_115(self.user.sender_id)
            return ['save',116,'L']
        else:
            return ['error',2]

    #LEER nuevo apellido materno
     
    def materno_remitente(self, payload):
        mothers_last_name = payload[1]
        names = self.ora.validaUsuario(self.user.sender_id)
        if self.ora.updateNombreUsuario(self.user.sender_id, names['nombre'], names['apPaterno'], mothers_last_name):
            names = [names['nombre'], names['apPaterno'], mothers_last_name]
            self.replies_bot.state_verify(self.user.sender_id, names)
            return ['save',112,'L']
        else:
            return ['error',2]

    #LEER fecha de nacimiento
     
    def fecha_nacimiento(self, payload):
        date = payload[1]
        if date != False:
            self.replies_bot.state_verify_date(self.user.sender_id,self.user.name,date[0])
            self.ora.updateFechaNacUsuario(self.user.sender_id, date[1])
            return ['save',122,'L']
        else:
            return ['error',2]

    #LEER confirmación de fecha de nacimiento
     
    def confirmar_fecha(self, payload):
            if payload[1].upper() == 'SI':
                return ['find',123]
            elif payload[1].upper() == 'NO':
                return ['save',121,'L']
                self.replies_bot.send_alert(self.user.sender_id, "Ingresa la fecha como en el ejemplo:\n20 de mayo de 1995")
                #return ['save', 121, 'L']
            else:
                return ['error',1]

    # LEER si/no numero telefonico
    @error_deco
    def telefono_celular(self, payload):
        if payload[1].upper() == 'SI':
            return ['find',126]
        elif payload[1].upper() == 'NO':
            confirmacion = 2
            telephone=''
            try:
                self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
                if self.user.firs_time == True:
                    return ['find', 133]
                else:
                    return ['find', 150]
            except Exception as e:
                print("Error:",e)
                error = 'Failed function because of {:}'.format(e)
                logger.write_error("replies -> " + "telefono_celular", error)
                return ['error', 1]
        elif payload[1].upper() == 'OTRO':
            confirmacion = 0
            telephone = ''
            try:
                self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
                data_user = self.ora.consultaDatosUsuario(self.user.sender_id)
                data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
                data_extra = self.ora.consultaExtras(self.user.sender_id)
                print(str(self.user.sender_id) + ": DATA BENEFICIARY----------------------------------------------\n" + str(data_beneficiary))
                quantity = data_beneficiary['quantity']
                quantityF = peticiones.EnvioCotizaP(data_extra['uid'], data_user['idCliente'], quantity)

                if self.user.firs_time == True:
                    return ['find', 133]
                else:
                    if quantityF[0] == True and quantityF[2].find("EXITOSA") > 0:
                        self.replies_bot.state_150(self.user.sender_id, data_user['nombre'], data_beneficiary['nombre'],data_beneficiary['apPaterno'], data_beneficiary['apMaterno'], quantity,quantityF[1])
                        return ['save', 151, 'L']
            except Exception as e:
                print("Error:",e)
                error = 'Failed function because of {:}'.format(e)
                logger.write_error("replies -> " + "telefono_celular", error)
                return ['error',1]
        else:
            return ['error',1]

    #lee telefono celular
    @error_deco
    def telefono_celular_validar(self, payload):
        consecutivo = ['0123456789', '9876543210']
        telephone = payload[1]
        replaced = re.sub('[^\d]', '', str(telephone))
        if len(replaced)!=10:
            return ['find', 128]
        lista_num = []
        for digito in replaced:
            lista_num.append(digito)
        #validacion de numeros repetidos
        repetidos = 1
        for d in range(0, len(lista_num) - 1):
            if lista_num[d] == lista_num[d + 1]:
                repetidos = repetidos + 1
                if repetidos >= 6 and lista_num[d - 1] == lista_num[d] and lista_num[d - 2] == lista_num[d]  and lista_num[d - 3] == lista_num[d] and lista_num[d - 4] == lista_num[d]:
                    return ['find', 251]
        #validacion de numero consecutivos
        ngram = ngrams(lista_num, 6)
        for n in ngram:
            cad = n[0] + n[1] + n[2] + n[3]+ n[4]+n[5]
            if consecutivo[0].find(cad) != -1:
                return ['find', 251]
            if consecutivo[1].find(cad) != -1:
                return ['find', 251]
        confirmacion=1
        try:
            self.ora.updateTelefono(self.user.sender_id, telephone,confirmacion)
            if self.user.firs_time == True:
                return ['find', 133]
            else:
                return ['find', 150]
        except Exception as e:
            print("Error:",e)
            error = 'Failed function because of {:}'.format(e)
            logger.write_error("replies -> " + "telefono_celular_validar", error)
            return ['error', 1]


    #lee telefono celular segunda vez
    @error_deco
    def telefono_celular_validar_segunda(self, payload):
        consecutivo = ['0123456789', '9876543210']
        telephone = payload[1]
        replaced = re.sub('[^\d]', '', str(telephone))
        if len(replaced)!=10:
            self.replies_bot.state_10(self.user.sender_id, self.user.name)
            return ['save', 20, 'L']
        lista_num = []
        for digito in replaced:
            lista_num.append(digito)
        #validacion de numeros repetidos
        repetidos = 1
        for d in range(0, len(lista_num) - 1):
            if lista_num[d] == lista_num[d + 1]:
                repetidos = repetidos + 1
                if repetidos >= 6 and lista_num[d - 1] == lista_num[d] and lista_num[d - 2] == lista_num[d] and lista_num[d - 3] == lista_num[d] and lista_num[d - 4] == lista_num[d]:
                    self.replies_bot.state_10(self.user.sender_id, self.user.name)
                    return ['save', 20, 'L']
        ngram = ngrams(lista_num, 6)
        for n in ngram:
            cad = n[0] + n[1] + n[2] + n[3]+ n[4]+ n[5]
            if consecutivo[0].find(cad) != -1:
                self.replies_bot.state_10(self.user.sender_id, self.user.name)
                return ['save', 20, 'L']
            if consecutivo[1].find(cad) != -1:
                self.replies_bot.state_10(self.user.sender_id, self.user.name)
                return ['save', 20, 'L']
        confirmacion = 1
        try:
            self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
            if self.user.firs_time == True:
                return ['find', 133]
            else:
                return ['find', 150]
        except Exception as e:
            print("Error 2",e)
            error = 'Failed function because of {:}'.format(e)
            logger.write_error("replies -> " + "telefono_celular_validar_segunda", error)
            return ['error', 1]


    #LEER confirmación de domicilio
     
    def confirmar_domicilio(self,payload):
        if payload[1].upper() == 'SI':
            print (self.user.firs_time)
            print ("mandar a estado 140")
            return ['find',140]
        elif payload[1].upper() == 'NO':
            return ['find',133]
        else:
            return ['error',1]

    #LEER calle y numero, y MOSTRAR ingresa colonia
     
    def calle_numero(self,payload):
        street = payload[1]
        especial_charts = ["-","&","_",":",",",".","/",";","#","(",")","[","]","*","=","°","!","$","%","?","¿"]
        for c in range(len(especial_charts)):
            street = street.replace(especial_charts[c],"")
        if len(street)>40:
            return ['error',2]
        else:
            if self.ora.updateDireccionUsuario(self.user.sender_id, street):
                self.ora.addExtra(self.user.sender_id,'calle_num',street)
                self.replies_bot.state_134(self.user.sender_id,self.user.name)
                return ['save',135,'L']
            else:
                return ['error',3]
       
    #LEER colonia y MOSTRAR ingresa CP
     
    def colonia(self,payload):
        colonia = payload[1]
        especial_charts = ["-","&","_",":",",",".","/",";","#","(",")","[","]","*","=","°","!","$","%","?","¿"]
        for c in range(len(especial_charts)):
            colonia = colonia.replace(especial_charts[c],"")
        data = self.ora.consultaDatosUsuario(self.user.sender_id)
        if self.ora.updateDireccionUsuario(self.user.sender_id, data['direccion'], None, None, None, colonia):
            self.replies_bot.state_135(self.user.sender_id)
            return ['save',136,'L']
        else:
            return ['error',2]

    #LEER código postal y manda a verificar
     
    def codigo_postal(self, payload):
        postal_code = payload[1]
        if len(postal_code)==5: 
            data = self.ora.consultaDatosUsuario(self.user.sender_id)
            address = {'calle_num':data['direccion'],'codigo_postal':postal_code,'colonia':data['colonia']}

            cp = self.ora.consultaCodigoPostal(postal_code)
            if not cp.get('cp'):
                self.replies_bot.state_137(self.user.sender_id)
                return ['save',137,'L']
            else:                                                                 
                if self.ora.updateDireccionUsuario(self.user.sender_id, data['direccion'], postal_code, cp['estado'].upper(),cp['municipio'].upper(), data['colonia']):
                    self.replies_bot.state_verify_address(self.user.sender_id, address)
                    return ['save',132,'L']
                else:
                    return ['error',2]
        else:
            return ['error',3]


    #LEER código postal si no existe se deja pasar
     
    def codigo_postal_again(self, payload):
        postal_code = payload[1]
        if len(postal_code)==5: 
            data = self.ora.consultaDatosUsuario(self.user.sender_id)
            address = {'calle_num':data['direccion'],'codigo_postal':postal_code,'colonia':data['colonia']}

            cp = self.ora.consultaCodigoPostal(postal_code)
            if not cp.get('cp'):
                self.ora.updateDireccionUsuario(self.user.sender_id, data['direccion'], postal_code, "Aguascalientes", "Aguascalientes", data['colonia'])
                self.replies_bot.state_verify_address(self.user.sender_id, address)
                return ['save',132,'L']
            else: 
                if self.ora.updateDireccionUsuario(self.user.sender_id, data['direccion'], postal_code, cp['estado'],cp['municipio'], data['colonia']):
                    self.replies_bot.state_verify_address(self.user.sender_id, address)
                    return ['save',132,'L']
                else:
                    return ['error',2]
        else:
            return ['error',3]

    #LEER confirmación de cotización
     
    def confirmar_cotizacion(self, payload):
        extra = self.ora.consultaExtras(self.user.sender_id)
        tipoFondeo=extra.get('tipo_fondeo')
        print(payload)
        if payload[1].upper() == 'SI':
            if (tipoFondeo == 'punto'):
                return ['find',152]
            else:
                return ['find',234]
        elif payload[1].upper() == 'NO':
            return ['find',153]
        elif payload[1] == '70':
            return ['find',70]
        elif payload[1] == '90':
            telephone=''
            confirmacion=3
            self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
            return ['find',90]
        else:
            return ['error',1]

    #LEER ubicación del usuario
     
    def ubicacion(self, payload):
        location = payload[1]
        if payload[0] == 'quick_replies' and payload[1] == "No_location":
            data_user = self.ora.consultaDatosUsuario(self.user.sender_id) 
            self.replies_bot.state_181(self.user.sender_id,data_user['nombre'])
            return ['find',250]
        elif payload[0] == 'location':
            #places_elektra = peticiones.busquedaTiendaP(location['lat'],location['long'])
            places_neto_emi = self.ora.consultaTiendas(location['lat'],location['long'])
            if places_neto_emi != False:
                places = places_neto_emi
                list_d = []
                for place in range(len(places)):
                    list_d.append(places[place]['distance'])
                list_d.sort()
                places_u = []
                for num in range(len(list_d)):
                    for place in range(len(places)):
                        if places[place]['distance'] == list_d[num]:
                            places_u.append(places[place])
                extras = self.ora.consultaExtras(self.user.sender_id)
                data_user = self.ora.consultaDatosUsuario(self.user.sender_id) 
                self.ora.updateLocalizacion(extras['folio'], location['lat'], location['long'])
                self.replies_bot.state_180(self.user.sender_id, places_u[:5],data_user['nombre'])
                self.replies_bot.state_181(self.user.sender_id,data_user['nombre'])
                self.ora.eliminaExtras(self.user.sender_id)
                print("Location")
                return ['find',250]
            else:
                print("Error")
                return ['error',2]
        else:
            return ['error',2]
    
     
    def busca_elektra(self,payload):
        location = payload[1]
        if payload[0] == 'quick_replies' and payload[1] == "No_location":
            return ['find',250]
        elif payload[0] == 'location':
            #places_elektra = peticiones.busquedaTiendaP(location['lat'],location['long'])
            places_neto_emi = self.ora.consultaTiendas(location['lat'],location['long'])
            if places_neto_emi != False:
                places = places_neto_emi
                list_d = []
                for place in range(len(places)):
                    list_d.append(places[place]['distance'])
                list_d.sort()
                places_u = []
                for num in range(len(list_d)):
                    for place in range(len(places)):
                        if places[place]['distance'] == list_d[num]:
                            places_u.append(places[place])
                data_user = self.ora.consultaDatosUsuario(self.user.sender_id) 
                self.replies_bot.show_stores_menu(self.user.sender_id, places_u[:5])
                return ['find',250]
            else:
                return ['error',1]

     
    def mostrar_motivos_cancelacion(self, payload):
        name = self.ora.consultaExtras(self.user.sender_id)
        motivo = payload[1]
        if payload[0] == 'quick_replies':
            if motivo != 'OTRO':
                self.ora.addCancelacion(name['beneficiary_id'],name['quantity'], motivo)
                return ['find', 5]
            else:
                self.replies_bot.state_154(self.user.sender_id)
                return ['save',155,'L']
        else:
            self.ora.addCancelacion(name['beneficiary_id'],name['quantity'], motivo)
            return ['find', 5]

     
    def leer_motivo(self, payload):
        name = self.ora.consultaExtras(self.user.sender_id)
        motivo = payload[1]
        self.ora.addCancelacion(name['beneficiary_id'],name['quantity'],motivo)
        return ['find', 5]

     
    def cotizacion(self,payload):
        print("****************=============================")
        print(payload)
        print("****************=============================")
        quantity = payload[1]
        response = FilterQuantity.validate(quantity)
        print('---------------------------------------------')
        print(response)
        if response[0]:
            quantity = response[1]
            uid = self.ora.generaUid()
            self.ora.addExtra(self.user.sender_id,'uid',uid['uid'])
            print(uid)
            cotizacion = peticiones.soloCotizaP(str(uid['uid']),quantity)
            print(cotizacion)
            if cotizacion[0]==True and cotizacion[2].find("EXITOSA")>0:
                self.ora.addExtra(self.user.sender_id, "quantity", str(quantity))
                self.ora.addExtra(self.user.sender_id, "quantityF", cotizacion[1])    
                #self.replies_bot.state225(self.user.sender_id,str(quantity),cotizacion[1])
                self.replies_bot.state_230(self.user.sender_id)
                #return ['save',226,'L']
                return ['save',231,'L']
            else:
                return ['error',3]
        else:
            return ['error',2]

     
    def confirmar_cotizacion_flujo2(self,payload):
        if payload[1].upper() == 'SI':
            if self.user.firs_time == True:
                    return ['find',50]  
            else:
                data_beneficiary = self.ora.consultaExtras(self.user.sender_id)
                data_user = self.ora.consultaDatosUsuario(self.user.sender_id)
                #listaNegra = peticiones.ClientValidaP(data_beneficiary['uid'],data_user['nombre'],data_user['apPaterno'],data_user['apMaterno'],data_user['fechaNac'])
                listaNegra = [True,'OPERACION EXITOSA',0]
                print(listaNegra)
                if listaNegra[0]==True and str(listaNegra[1])=='OPERACION EXITOSA':
                    print("Entre")
                    self.ora.updateListaNegra(self.user.sender_id,listaNegra[2])
                    if listaNegra[2]==0 or listaNegra[2]==2:
                        print("Yeah")
                        return ['find',50]
                    elif listaNegra[2]==1 or listaNegra[2] == 3:
                        print("Ñio :(")
                        return ['error',4]
                    elif listaNegra[2]==4 or listaNegra[2]==5:
                        print("Ya que")
                        return ['error',5]
                    else:
                        print("en esle")
                        return ['find',160]
                else:
                    print("No srivios")
                    return ['find',160]
        elif payload[1].upper() == 'NO':
            return ['find',5]
        else:
            return ['error',2]

    #69
     
    def leer_aceptar_terminos_condiciones(self,payload):
        if payload[1].upper() == 'SI':
            self.ora.updateAceptaTerminos(self.user.sender_id)
            return ['find',50]
        elif payload[1].upper() == 'NO':
            return ['find',5]
        elif payload[1].upper() == 'TYC':
            return ['find',42]
        else:
            return ['error',1]

     
    def hablar_con_humano(self):

        in_time = self.replies_bot.validate_day_hour()

        if in_time == True:
            if self.ora.habilitarBot(self.user.sender_id, '1'):
                text = "Hola "+str(self.user.name).upper()+" bienvenido al centro de atención de Dinero Express. ¿En que podemos apoyarte?"
                self.replies_bot.send_alert(self.user.sender_id, text)
                self.replies_bot.send_action(self.user.sender_id,3)
                self.replies_bot.send_action(self.user.sender_id,1)
                self.replies_bot.send_action(self.user.sender_id,1)
                self.replies_bot.send_action(self.user.sender_id,1)
                storageRequest = storageConversationModule(self.user,self.ora)
                storageRequest.getMessages(self.user.sender_id,self.user.name,self.user.last_name,self.user.mothers_last_name)
            else:
                return ['error',1]
                
            return ['save', 10, 'L']
        else:
            text_service_time = "Horario fuera de servicio :(, nuestro horario de atención es de 9 am a 9 pm de Lunes a Domingo"
            self.replies_bot.send_alert(self.user.sender_id, text_service_time)
            return ['find',5]
        
     
    def motivos_callcenter(self,payload):
        motivo = payload[1]
        print("Motivo callcenter " + str(motivo))

        if self.ora.habilitarBot(self.user.sender_id, '1'):
            text = 'En un momento un agente se pondrá en contacto :D'
            self.replies_bot.send_alert(self.user.sender_id, text)
            storageRequest = storageConversationModule(self.user,self.ora)
            storageRequest.getMessages(self.user.sender_id,self.user.name,self.user.last_name,self.user.mothers_last_name,motivo)
        else:
            return ['error',2]
        return ['save', 10, 'L']

    def tipo_de_fondeo(self, payload):
        print(payload)
        if payload[1].upper() == 'PUNTO':
            self.ora.addExtra(self.user.sender_id, "tipo_fondeo", "punto") 
            return ['find',235]
        elif payload[1].upper() == 'TCD':
            self.ora.addExtra(self.user.sender_id, "tipo_fondeo", "tarjeta") 
            return ['find',236]
        elif payload[1] == 'CANCELAR':
            return ['find',153]
        else:
            return ['error',1]

