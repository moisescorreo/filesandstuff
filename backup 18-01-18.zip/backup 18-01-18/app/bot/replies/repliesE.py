import logging
from io import StringIO
from crash_report import send_sms
import modules.logger_register as logger

class Replies_E(object):
    """Clase de estados de mostrar"""
    def __init__(self, user, ora, replies_bot):
        self.user = user
        self.ora = ora
        self.replies_bot = replies_bot
    
    def error_deco(func): 
        """decorator function"""
        def handle_error(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error = 'Failed function because of {:}'.format(e)
                logger.write_error("repliesE", error)
                return ['error',1]
        return handle_error
        
     
    def cancela_instentos(self):
        state = self.ora.consultaEstado(self.user.sender_id)
        if self.ora.eliminaExtras(self.user.sender_id):
            self.replies_bot.state_4(self.user.sender_id)
            self.replies_bot.state_restart(self.user.sender_id, self.user.name)
            status = self.ora.consultaStatusTelefono(self.user.sender_id)
            if status == 3:
                telephone = ''
                confirmacion = 0
                self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
            return ['save',20,'L']
        else:
            return ['error',1]

    #CANCELA transaccion en curso
     
    def cancela_transaccion(self):
        state = self.ora.consultaEstado(self.user.sender_id)
        if state['estAnterior'] > 50:
            if self.ora.eliminaExtras(self.user.sender_id):
                self.replies_bot.state_5(self.user.sender_id)
                self.replies_bot.state_restart(self.user.sender_id, self.user.name)

                status = self.ora.consultaStatusTelefono(self.user.sender_id)
                if status==3:
                    telephone = ''
                    confirmacion = 0
                    self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
                return ['save',20,'L']
            else:
                return ['error',1]
        else: 
            if self.ora.eliminaExtras(self.user.sender_id):
                self.replies_bot.state_restart(self.user.sender_id, self.user.name)
                status = self.ora.consultaStatusTelefono(self.user.sender_id)
                if status == 3:
                    telephone = ''
                    confirmacion = 0
                    self.ora.updateTelefono(self.user.sender_id, telephone, confirmacion)
                return ['save',20,'L']
            else:
                return ['error',1]

    #MOSTRAR número de contacto
     
    def numero_contacto(self):
        self.replies_bot.state_7(self.user.sender_id)
        self.replies_bot.state_menu(self.user.sender_id, "Para realizar alguna operación regresa al menú principal")
        return ['save',41,'L']

    #MOSTRAR quick replies yes/no
     
    def yes_no(self):
        self.replies_bot.show_yes_no(self.user.sender_id, "Responde con un Si o un No por favor")
        return ['True','']

    #MOSTRAR botones ayuda
     
    def botones_ayuda(self):
        #Ayuda: terminos y condiciones y políticas de privacidad
        self.replies_bot.state_30(self.user.sender_id)
        return ['save',31,'L']

    #MOSTRAR los términos y condiciones, políticas de privacidad
     
    def terminos_condiciones(self,payload=None):
        #politicas de privacidad DB guardar estado 20 en base de datos
        self.replies_bot.state_40(self.user.sender_id)
        self.replies_bot.state_menu(self.user.sender_id, "Para realizar alguna operación regresa al menú principal")
        return ['save',41,'L']

    #VERIFICAR si es la primera vez del usuario
     
    def verificar(self):
        tyc = self.ora.consultaAceptaTerminos(self.user.sender_id)
        print(str(tyc))
        if tyc['tyc'] == 1 :
            if self.user.firs_time == True:
                return ['find',60]
            else:
                return ['find',70]
        else:
            return ['find',68] 

    #MOSTRAR ingresar nombre del beneficiario
     
    def ingresa_nombre_beneficiario(self):
        self.replies_bot.state_60(self.user.sender_id, self.user.name)
        return ['save',61,'L']

    #MOSTRAR corrige nombre
     
    def corrige_nombre(self):
        self.replies_bot.state_63(self.user.sender_id)
        return ['save',64,'L']

    #MOSTRAR botones de opciones para seleccionar beneficiario
     
    def botones_seleccion_beneficiario(self):
        beneficiaries = self.ora.consultaBeneficiarios(self.user.sender_id)
        print(len(beneficiaries))
        if len(beneficiaries)<10:
            self.replies_bot.state_70(self.user.sender_id)
        else:
            self.replies_bot.state_71(self.user.sender_id)
        return ['save',71,'L']

    #OBTENER contactos y MOSTRAR contactos en botones
     
    def contactos(self,payload=None):
        try:
            beneficiaries = self.ora.consultaBeneficiarios(self.user.sender_id)
            if len(beneficiaries)==0:
                self.replies_bot.send_alert(self.user.sender_id,"No hay beneficiarios registrados.")
                return ['find',60]
            else:
                self.replies_bot.state_80(self.user.sender_id,beneficiaries)
                return ['save',81,'L']
        except:
            #return ['find', 5]
            return ['error',1]

     
    def pregunta_estado_editar(self):
        beneficiary=self.ora.consultaExtras(self.user.sender_id)
        self.replies_bot.state_82(self.user.sender_id,beneficiary['nombre'],beneficiary['apPaterno'],beneficiary['apMaterno'])
        return ['save',89,'L']

     
    def pregunta_estado(self):
        beneficiary=self.ora.consultaExtras(self.user.sender_id)
        self.replies_bot.state_91(self.user.sender_id,beneficiary['nombre'],beneficiary['apPaterno'],beneficiary['apMaterno'])
        return ['save',89,'L']

    #Despliega los estados alfabeticamente
     
    def despliega_estados(self):
        self.replies_bot.state_85(self.user.sender_id)
        return ['save',86,'L']

    #MOSTRAR pregunta de monto
     
    def pregunta_monto(self):
        contact = self.ora.consultaExtras(self.user.sender_id)
        self.replies_bot.state_90(self.user.sender_id, contact['nombre'])
        return ['save',100,'L']

    #MOSTRAR ingresa tu nombre completo
     
    def ingresa_nombre_remitente(self):
        if self.user.firs_time == True:
            self.replies_bot.state_110(self.user.sender_id, self.user.name)
            return ['save',111,'L']
        else:
            return ['find',140]

    #MOSTRAR corrige nombre
     
    def corrige_nombre_remitente(self):
        self.replies_bot.state_113(self.user.sender_id)
        return ['save',114,'L']

    #MOSTRAR mensaje de fecha de nacimiento
     
    def fecha_nacimiento(self):
        self.replies_bot.state_120(self.user.sender_id, self.user.name)
        return ['save',121,'L']


    # MOSTRAR desea ingresar telefono
    @error_deco
    def telefono_celular(self):
        self.replies_bot.state_124(self.user.sender_id, self.user.name)
        return ['save', 125, 'L']

    # MOSTRAR ingresar telefono
    @error_deco
    def pide_telefono(self):
        self.replies_bot.state_126(self.user.sender_id, self.user.name)
        return ['save', 127, 'L']

    # MOSTRAR ingresar telefono nuevamente longitud incorrecta
    @error_deco
    def pide_telefono_longitud_incorrecta(self):
        self.replies_bot.state_128(self.user.sender_id, self.user.name)
        return ['save', 129, 'L']


    # MOSTRAR ingresar telefono nuevamente numero invalido

    @error_deco
    def pide_telefono_numero_invalido(self):
        self.replies_bot.state_251(self.user.sender_id, self.user.name)
        return ['save', 129, 'L']


    #MOSTRAR ingresar información de domicilio
     
    def ingresa_domicilio(self):
        self.replies_bot.state_130(self.user.sender_id, self.user.name)
        return ['save',133,'L']

    #MOSTRAR ingresa calle y numero
     
    def calle_numero(self):
        self.replies_bot.state_130(self.user.sender_id,self.user.name)
        return ['save',134,'L']

    # RETORNO al principio
     
    def regresa_inicio(self):
        self.replies_bot.state_160(self.user.sender_id)
        return ['find',5]

    # Exit bot
     
    def finish(self):
        self.replies_bot.state_exit(self.user.sender_id, self.user.name)
        return ['save',10,'L']

     
    def busca_elektra(self):
        self.replies_bot.find_elektra_location(self.user.sender_id)
        return ['save',200,'L']

     
    def motivo_de_cancelacion(self):
        text = "¿Cuáles son sus motivos de cancelación?"
        self.replies_bot.state_153(self.user.sender_id, text)
        return ['save',154,'L']

     
    def pregunta_monto_cotizacion(self):
        self.replies_bot.state220(self.user.sender_id)
        return ['save',225,'L']

     
    def error_confirmacion_transaccion(self):
        self.replies_bot.state_150_error(self.user.sender_id)
        return ['save',151,'L']

    #MUESTRA leyenda para aceptar terminos y condicines 68
     
    def aceptar_terminos_condiciones(self):
        self.replies_bot.state_68(self.user.sender_id)
        return ['save',69,'L']

     
    def terminos_condiciones2(self,payload=None):
        self.replies_bot.state_40(self.user.sender_id)
        return ['find',68]

     
    def hablar_con_humano(self):
        self.replies_bot.state_32(self.user.sender_id)
        return ['save',33,'L']

    def tipo_de_fondeo(self):
        self.replies_bot.state_230(self.user.sender_id)
        return ['save',231,'L']

    def error_tipo_de_fondeo(self):
        self.replies_bot.state_230_error(self.user.sender_id)
        return ['save',231,'L']

    def opcion_pago_tarjeta(self):
        self.replies_bot.state_234(self.user.sender_id)
        return ['save',231,'L']

    def confirmar_cotizacion_punto(self):
        extra = self.ora.consultaExtras(self.user.sender_id)
        quantity=extra.get('quantity')
        quantityF=extra.get('quantityF')
        self.replies_bot.state225(self.user.sender_id,str(quantity),quantityF,1)
        return ['save',226,'L']

    def confirmar_cotizacion_tarjeta(self):
        extra = self.ora.consultaExtras(self.user.sender_id)
        quantity=extra.get('quantity')
        quantityF=extra.get('quantityF')
        self.replies_bot.state225(self.user.sender_id,str(quantity),quantityF,2)
        return ['save',226,'L']
