#!/usr/bin/env python
# -*- coding: utf-8 -*-
from flask import Flask, request, send_from_directory,jsonify,render_template
import requests
import json
import os, time
import modules.ticket as ticket
from bot.botDEX import BotDEX
from pymessenger.bot import Bot
from replies_bot import RepliesBot
from bdoracle import Orabd
from modules.recordatorio import Recordatorio
from analytics import analyticsBot
from S1 import s1Module
import modules.logger_register as logger
import atexit

os.environ["NLS_LANG"] = ".AL32UTF8"

app = Flask(__name__, static_url_path='')

ACCESS_TOKEN = os.environ['ACCESS_TOKEN_FACEBOOK']
VERIFY_TOKEN = os.environ['VERIFY_TOKEN_FACEBOOK']

analyticsRequest = analyticsBot()

ora = Orabd()
bot = Bot(ACCESS_TOKEN)
replies_bot = RepliesBot(bot)
s1Request = s1Module()

temporizador = Recordatorio(bot)
temporizador.hilo()

def cathErrors(var):
	def handle_function(func):
		def handle_error(*args, **kwargs):
			try:
				print("decorator " + var)
				result = func(*args, **kwargs)
			except Exception as e:
				print(var + str(e.args))
				logger.write_error(var, str(e.args))
				return False
			return result
		handle_error.__name__ = func.__name__
		return handle_error
	return handle_function

@app.route('/')
def home():
	print("Inicio del servidor")
	return 'Incio del server del servidor'


#{'uid': 'UID0000000000001', 'codigoSalida': 'X', 'folioTransferencia': '21421172297', 'mensajeSalida': 'EXITOSO'}
@app.route('/estadoActualiza', methods=['PUT'])
#@cathErrors("Estado Actualiza")
def actualiza_servicio():
	if request.method=='PUT':
		try:
			print(request)
			print(request.json)
			data = request.json
			logger.write_info("Estado Actualiza", str(data))
			new_state_tranfer = ora.updateEnvio(data["folioTransferencia"],data['codigoSalida'],data["mensajeSalida"])
			print("--------------NEW STATE SENDER -----------")
			print(new_state_tranfer)
			if new_state_tranfer != False and data['codigoSalida'] == 'X':
				name_ticket= str(new_state_tranfer['idSender'])
				lista_datos = {'beneficiaryName': new_state_tranfer['beneficiaryName'], 'beneficiaryLastName': new_state_tranfer['beneficiaryLastName'], 'userName': new_state_tranfer['userName'], 'userLastName': new_state_tranfer['userLastName'], 'destiny': new_state_tranfer['destiny'], 'folio': data["folioTransferencia"], 'quantity': int(new_state_tranfer['quantity']), 'tarifa': int(new_state_tranfer['tarifa']), 'civa': int(new_state_tranfer['civa']), 'quantityT': int(new_state_tranfer['quantityT'])}
				ticket.save_ticket(lista_datos, name_ticket)
				image_url ="https://www.qabot.dineroexpress.com.mx/img/"+str(name_ticket)+".png"
				replies_bot.update_state(new_state_tranfer['idSender'], new_state_tranfer['beneficiaryName'], image_url,new_state_tranfer['quantity'],data["folioTransferencia"])
				analyticsRequest.sendAnalyticsEvent(data['codigoSalida'],new_state_tranfer['idSender'],new_state_tranfer['idSender'])
			elif new_state_tranfer != False and data['codigoSalida'] == 'CA':
				replies_bot.update_state_cancel(new_state_tranfer['idSender'], new_state_tranfer['beneficiaryName'],new_state_tranfer['quantity'],data["folioTransferencia"])
				analyticsRequest.sendAnalyticsEvent(data['codigoSalida'],new_state_tranfer['idSender'],new_state_tranfer['idSender'])
			elif new_state_tranfer != False and data['codigoSalida'] == 'C':
				replies_bot.update_state_cobrado(new_state_tranfer['idSender'], new_state_tranfer['beneficiaryName'],new_state_tranfer['quantity'],data["folioTransferencia"])
				analyticsRequest.sendAnalyticsEvent(data['codigoSalida'],new_state_tranfer['idSender'],new_state_tranfer['idSender'])

			else:
				data = {"uid":data["uid"],"mensaje":"","folioTransferencia":data["folioTransferencia"],"error": "No se proceso la notificacion"}
				response = jsonify(data)
				return response					
			data = {"uid":data["uid"],"mensaje":"Estado Actualizado","folioTransferencia":data["folioTransferencia"],"error": ""}
			response = jsonify(data)
			return response
		except Exception as e:
			data = {"uid":data["uid"],"mensaje":"","folioTransferencia":"","error": "No se proceso la notificacion"}
			print(data)
			response = jsonify(data)
			print(response)

			print(str(e))
			return response

@app.route('/avisos')
def politics():
	return render_template('Aviso.html')

@app.route('/condiciones')
def condiciones():
	return render_template('Terminos.html')

@app.route('/webviews/<path:path>')
def webviews(path):
    return send_from_directory('webviews', path)

@app.route('/img/<path:path>')
def img(path):
    return send_from_directory('img', path)

@app.route('/webhooknew', methods=['GET', 'POST'])
#@cathErrors("Webhook")
def webhook():
	print("webhook")
	if request.method == 'POST':
		output = request.get_json()
		print('*******************************************JSON************************************************')
		print(output)
		print('***********************************************************************************************')
		for event in output['entry']:
			messaging = event['messaging']
			for eventMessage in messaging:
				recipient_id = eventMessage['sender']['id']
				analitycs_id = eventMessage['recipient']['id']
				DEX = BotDEX(recipient_id,analitycs_id,ora)
				DEX.start(eventMessage)
	elif request.method == 'GET':
		print(VERIFY_TOKEN)
		if request.args.get('hub.verify_token') == VERIFY_TOKEN:
			return request.args.get('hub.challenge')
		return "Verificar el token"

	return "Chatbot Grupo Salinas"


@app.route('/S1', methods = ['GET', 'POST'])
#@cathErrors("S1")
def S1():
	if request.method == 'POST':
		try:
			json1= json.loads(request.get_data(as_text=True))
			logger.write_info("S1", str(json1))
			agent_name = json1["agent_name"]
			sender_id = json1["ext_id"]
			dateMessage = json1["msg_ts"]
			message = json1["text"]
			endSession = json1["end_session"]
		except KeyError:
			return "Error: Revisa la petición, faltan argumentos ",400
		jsonprov = ora.consultaDisponibleS1(sender_id)
		if jsonprov["disponible"] == "1" :
			s1Request.incomingmessage(agent_name,sender_id,dateMessage,message,endSession)
			if endSession =="1":
				ora.habilitarBot(sender_id,"0")
				s1Request.sendBackBot(sender_id)
				return "Mensaje enviado y cerrar sesion con el usuario exitosos",201
			else:
				return "Mensaje enviado al cliente exitosamente"
		else:
			return "el usuario al que estas intentando contactar no tiene una sesión de chat abierta , revisa que el id_ext sea correcto y que en peticiones anteriores no mandaste end_session = 1 ",403
	elif request.method == 'GET':
		return "Hello World to S1 endpoint :) !"

@app.route('/extensionService', methods = ['GET','POST'])
def extensionService():
    if request.method == 'POST':
        json1= request.get_json()
        print(json1)
        try:
            service_name = json1['service_name']
            sender_id = json1['sender_id']
            token = json1['token']
        except KeyError as e:
            return "Error en los parametros de la peticion :"+ str(e) ,400
        return "validado correctamente",200
    elif request.method == 'GET':
        return "Hello world extension Index"

@app.route('/extensionIndex', methods = ['GET'])
def extensionIndex():
	if request.method == 'GET':
		return "Hello world extension Index"

@app.route('/extensionLogin', methods = ['GET'])
def extensionLogin():
	if request.method == 'GET':
		return "Hello world extension Login"

@app.route('/extensionRegister', methods = ['GET'])
def extensionRegister():
	if request.method == 'GET':
		return "Hello world extension Register"

@app.route('/extensionCards', methods = ['GET'])
def extensionCards():
	if request.method == 'GET':
		return "Hello world extension Cards"


app.register_error_handler(400, lambda e: 'Petición erronea , revisa la sintaxis de la petición!')

@atexit.register
def finish_app():
	logger.write_info("APP","Se cerró la app")

if __name__ == '__main__':
	app.run(host="127.0.0.1", port=5000, debug=True, threaded=True)
