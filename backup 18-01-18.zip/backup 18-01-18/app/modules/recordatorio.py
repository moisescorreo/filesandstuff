from threading import Timer
from datetime import datetime,timedelta
import os
os.environ["NLS_LANG"] = ".AL32UTF8"
from bdoracle import Orabd
import json

class Recordatorio():

    def __init__(self, bot):
        super().__init__()
        self.ora = Orabd()
        self.bot = bot

    def seconds(self):
        x = datetime.today()
        fecha = x + timedelta(days=1)
        y = x.replace(day=fecha.day, month=fecha.month, hour=9, minute=0, second=0, microsecond=0)
        delta_t = y - x
        secs = delta_t.seconds + 1
        return secs

    def checkNotify(self):
        data = self.ora.recordatorio()
        print("checkNotify . . . . . . . . NEXT IN: " + str(self.seconds()) + " SECONDS")
        #dataDict = [{'monto': 21.0, 'folio': 57299786118, 'fechaEscrita': '23 de Julio del 2017', 'userName': 'Raúl', 'fechaCaducidad': '20/07/2017', 'beneficiaryName': 'Rodrigo Medina Neri', 'senderID': 1377961855631993}]
        #dataDump = json.dumps(dataDict)
        #data = json.loads(dataDump)
        for row in data:
            print(row)
            self.notifyAlert(row)
        return True

    def notifyAlert(self, row):
        self.buttons = {'state7':[{"content_type":"text","title":"Menú principal","payload":"CANCELAR_OPERACION" }]}
        if self.ora.updateNotificado(row['folio']):
            print("El usuario: "+ str(row['userName']) + "ha sido notificado")
            message=str(row['userName'].upper()) + ". Recuerda que tu envío con referencia " + str(row['folio']) + " con un monto de $" + str(int(row['monto'])) + " 💵💵💵 para " + str(row['beneficiaryName'].upper()) + " está próxima a vencer el día " + str(row['fechaEscrita']) + ", puedes acudir a cuarquier punto de pago. ¡Tenemos más de 5 mil en todo México! 🏪"
            #self.bot.send_text_message(row['senderID'],message)
            self.bot.send_quick_replies(row['senderID'], message, self.buttons['state7'])
            return True
        else:
            return False

    def hilo(self):
        self.checkNotify()
        timer = Timer(self.seconds(), self.hilo)
        timer.start()