import logging.handlers
import time
from bdoracle import Orabd
from crash_report import send_sms

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

handler = logging.handlers.RotatingFileHandler(filename='../logs/logs.log', mode='a', maxBytes=1024000, backupCount=100)
handler.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
handler.setFormatter(formatter)

logger.addHandler(handler)
ora = Orabd()


def write_info(tag, message):
    logger.info(tag + " | " + message + "|")
    fecha = time.strftime("%d-%m-%Y")
    hora = time.strftime("%H:%M:%S")
    clob1 = "~| INFO |" + fecha + " " + hora + " | " + tag + " | " + message + "|"
    ora.ejecutaBitacora(1,tag,message,clob1)
    print("Log INFO '" + tag + " | " + message + "' escrito.")

def write_error(tag, message):
    logger.error(tag + " | " + message)
    fecha = time.strftime("%d-%m-%Y")
    hora = time.strftime("%H:%M:%S")
    clob1 ="~| ERROR |"  + fecha + " " + hora + " | " + tag + " | " + message + "|"
    ora.ejecutaBitacora(1, tag, message, clob1)
    print("Log ERROR '" + tag + " | " + message + "' escrito.")
