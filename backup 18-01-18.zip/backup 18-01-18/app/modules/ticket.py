# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime,timedelta
import code128
import os
import time

Rfont = ImageFont.truetype("sources/DejaVuSans.ttf", 40)
Rfont1 = ImageFont.truetype("sources/DejaVuSans.ttf", 18)
Rfont2 = ImageFont.truetype("sources/DejaVuSans.ttf", 25)


def generar_barcode(folio):
	image = code128.image(str(folio))
	return image 

def get_month(mes):
	months = {1:'Enero',2:'Febrero',3:'Marzo',4:'Abril',5:'Mayo',6:'Junio',7:'Julio',8:'Agosto',9:'Septiembre',10:'Octubre',11:'Noviembre',12:'Diciembre'}
	return months[mes]

def generar_reference_ticket(lista_datos):
	format_date = '%d/%m/%y'
	datetime_object = datetime.strptime(lista_datos['date'], format_date).date()
	vigencia = datetime_object + timedelta(days=2)

	ticket = Image.open('sources/pasos.png')

	draw = ImageDraw.Draw(ticket)
	draw.text((68, 490), "Referencia vigente al " + str(vigencia.day) +" de "+get_month(vigencia.month)+" del "+str(vigencia.year), font=Rfont1, fill="black")

	barcode_image = generar_barcode(lista_datos['folio'])
	barcode_image = barcode_image.resize((350, 160))
	ticket.paste(barcode_image, (75, 540))

	draw.text((115, 715), str(lista_datos['folio']), font=Rfont, fill="black")
	return ticket

def generar_ticket(lista_datos):
	ticket = Image.open('sources/ticket.png')
	draw = ImageDraw.Draw(ticket)
	draw.text((230, 322), lista_datos['folio'], font=Rfont2, fill="black")
	draw.text((230, 460), lista_datos['beneficiaryName'], font=Rfont2, fill="black")
	draw.text((230, 484), lista_datos['beneficiaryLastName'], font=Rfont2, fill="black")
	draw.text((230, 527), lista_datos['userName'], font=Rfont2, fill="black")
	draw.text((230, 551), lista_datos['userLastName'], font=Rfont2, fill="black")
	#draw.text((230, 599), lista_datos['destiny'], font=Rfont2, fill="black")
	draw.text((230, 599), "------", font=Rfont2, fill="black")
	draw.text((230, 671), "$"+str(lista_datos['quantity']) + "." + u'\u2070' + u'\u2070', font=Rfont2, fill="black")
	draw.text((230, 710), "$" + str(lista_datos['tarifa']) + "." + u'\u2070' + u'\u2070', font=Rfont2, fill="black")
	draw.text((230, 748), "$" + str(lista_datos['civa']) + "." + u'\u2070' + u'\u2070', font=Rfont2, fill="black")
	draw.text((230, 791), "$" + str(lista_datos['quantityT']) + "." + u'\u2070' + u'\u2070', font=Rfont2, fill="black")
	return ticket

def save_ticket(lista_datos, name):
	#lista_datos = {'date':"12/02/17", 'quantity':"500", 'civa':"50",'quantityT':"550", 'beneficiary':"Marcela Perez Durán", 'folio':"123456789012"}
	ticket = generar_ticket(lista_datos)
	ticket.save("img/"+name+".png")

def save_reference_ticket(lista_datos, name):
	init = time.time()
	ticket = generar_reference_ticket(lista_datos)
	ticket.save("img/"+name+".png")
	end = time.time()
	print("Time fot save references: " + str(end-init))