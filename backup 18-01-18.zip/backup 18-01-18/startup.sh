source /home/plincos123/Escritorio/Bot/env/bin/activate
/home/plincos123/Escritorio/Bot/load.sh
cd /home/plincos123/Escritorio/Bot/app
echo $BASE_URL_API_SALINAS
gunicorn --bind 127.0.0.1:5000 wsgi --threads 12 --worker-connections 5

