killall gunicorn
